# 05 Certification FAQ

### Q1. What certification and training programs does PMI Chennai Chapter offer?

PMICC's Certification & Training page lists preparatory training for PMI-ACP (via 'ACP & Beyond'), a PgMP orientation program, and hands-on workshops including Microsoft Project Essentials, JIRA Basics, ProjectLibre Essentials, and Primavera Essentials. The main site navigation also lists separate pages for PMP Certification Training, PMI ACP Certification Training, PgMP Certification Training, an Oracle Primavera Workshop, Design Thinking for Project Managers, a Power BI workshop, a leadership workshop ('Lead Up'), an Introduction to Blockchain Technology, an Artificial Intelligence Workshop, and Essentials of Project Management Using Microsoft Project.

**Category:** Certification / Programs Offered  
**Source:** [Certification & Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** High  
**Tags:** certification programs, PMP, PMI-ACP, PgMP, workshops, training catalog

**Related questions:**
- Who do I contact to register for PMICC training or certification programs?
- How much did the PgMP one-day training program cost?
- How do I pay for a PMICC training program by bank transfer?

---

### Q2. Who do I contact to register for PMICC training or certification programs?

Registration and certification-training queries go to vpcertification@pmi-chennai.org (also referenced historically as Training@pmi-chennai.org for payment confirmations).

**Category:** Certification / Who To Contact  
**Source:** [Certification & Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** High  
**Tags:** registration, training contact, vpcertification

**Related questions:**
- What certification and training programs does PMI Chennai Chapter offer?
- How much did the PgMP one-day training program cost?
- How do I pay for a PMICC training program by bank transfer?

---

### Q3. How much did the PgMP one-day training program cost?

In an archived listing on the site, the 1-Day PgMP Training Program was priced at Rs. 4,000 + 18% GST for PMI Chennai members and Rs. 6,000 + 18% GST for non-members. This is historical/example pricing from a past batch, not a standing current fee — always confirm current pricing directly with vpcertification@pmi-chennai.org.

**Category:** Certification / Fees (Historical Example)  
**Source:** [Certification & Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** Medium  
**Tags:** PgMP fee, training cost, pricing example

**Related questions:**
- What certification and training programs does PMI Chennai Chapter offer?
- Who do I contact to register for PMICC training or certification programs?
- How do I pay for a PMICC training program by bank transfer?

---

### Q4. How do I pay for a PMICC training program by bank transfer?

An archived workshop listing gives these bank transfer details: Account Name: PMI Chennai Chapter; Bank: Kotak Mahindra Bank; Branch: Adyar; Account type: Current account; Account No: 5711125967; IFSC Code: KKBK0000463. After transferring, participants were asked to email a screenshot of the transaction to Training@pmi-chennai.org / vpcertification@pmi-chennai.org for reconciliation. Confirm these details are still current before making a payment, since this was found on an older archived page.

**Category:** Certification / Payment  
**Source:** [Certification & Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** Medium  
**Tags:** bank transfer, payment, IFSC, account number

**Related questions:**
- What certification and training programs does PMI Chennai Chapter offer?
- Who do I contact to register for PMICC training or certification programs?
- How much did the PgMP one-day training program cost?

---

### Q5. Do PMICC workshops offer PDUs?

Yes, several archived workshop listings (e.g. Microsoft Project 2016 Essentials, JIRA, Project Libre Essentials, Primavera Essentials) awarded 6.0 PDUs each. PDU amounts vary by workshop; check the specific event page for current figures.

**Category:** Certification / PDUs  
**Source:** [Certification & Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** High  
**Tags:** PDU, professional development units, 6.0 PDUs

**Related questions:**
- What certification and training programs does PMI Chennai Chapter offer?
- Who do I contact to register for PMICC training or certification programs?
- How much did the PgMP one-day training program cost?

---


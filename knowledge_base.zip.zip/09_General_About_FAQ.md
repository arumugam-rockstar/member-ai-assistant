# 09 General About FAQ

### Q1. What is PMI Chennai Chapter (PMICC)?

The PMI Chennai Chapter (PMICC) is a non-profit oriented chartered component of the Project Management Institute (PMI), which is headquartered in Newtown Square, Pennsylvania, USA. PMICC is registered as a society under the Tamil Nadu Registration of Societies Act, making it a not-for-profit, tax-exempt membership society.

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** about, PMICC, non-profit, PMI

**Related questions:**
- When was PMI Chennai Chapter founded?
- What is PMICC's motto or guiding philosophy?
- What is the vision of PMI Chennai Chapter?

---

### Q2. When was PMI Chennai Chapter founded?

PMICC was founded in 2002, when a group of visionaries headed by Dr. P. N. Sridharan initiated a new PMI-affiliated chapter in Chennai.

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** history, inception, 2002, founding

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- What is PMICC's motto or guiding philosophy?
- What is the vision of PMI Chennai Chapter?

---

### Q3. What is PMICC's motto or guiding philosophy?

PMICC's motto is to be an organisation 'of the members', 'by the members' and 'for the members', with an emphasis on serving Academia, Business, and Community (the 'ABCs').

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** motto, principles, goal

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- When was PMI Chennai Chapter founded?
- What is the vision of PMI Chennai Chapter?

---

### Q4. What is the vision of PMI Chennai Chapter?

PMICC's vision is Regional Excellence in the Practice of Project Management through modern, structured management-of-projects concepts that are widely recognized and consistently applied.

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** vision

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- When was PMI Chennai Chapter founded?
- What is PMICC's motto or guiding philosophy?

---

### Q5. What is the mission of PMI Chennai Chapter?

PMICC's mission is to: (1) assist in improving the understanding and ability of experienced and new project management practitioners and customers, (2) assist in improving the maturity and quality of project management practitioners, (3) create awareness in the younger generation at school and college levels, and (4) propagate generally accepted project management approaches and the guide to PMBOK.

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** mission

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- When was PMI Chennai Chapter founded?
- What is PMICC's motto or guiding philosophy?

---

### Q6. Where is the PMI Chennai Chapter office located?

PMICC's registered address is: Project Management Institute Chennai Chapter, 715-A, 7th Floor, Spencer Plaza, Suite No.1182, Anna Salai, Chennai - 600 002.

**Category:** General / Contact  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** office, address, location, Spencer Plaza

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- When was PMI Chennai Chapter founded?
- What is PMICC's motto or guiding philosophy?

---

### Q7. What is PMI Chennai Chapter's phone number?

The chapter's listed mobile number on the homepage is +91 87785 66932.

**Category:** General / Contact  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** phone, contact number

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- When was PMI Chennai Chapter founded?
- What is PMICC's motto or guiding philosophy?

---

### Q8. How can I contact PMI Chennai Chapter for volunteering, training, or website queries?

For chapter volunteering queries, email vpvolunteers@pmi-chennai.org. For training program queries, email vpprograms@pmi-chennai.org. For chapter website queries, email vptechnology@pmi-chennai.org.

**Category:** General / Contact  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** contact, email, queries, volunteering contact, training contact, website contact

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- When was PMI Chennai Chapter founded?
- What is PMICC's motto or guiding philosophy?

---

### Q9. What are PMI Chennai Chapter's social media handles?

PMICC is present on Facebook (facebook.com/pmichennai), Twitter/X (@pmichennai), LinkedIn (linkedin.com/school/pmichennai), YouTube, and WhatsApp (a WhatsApp channel link is provided on the site).

**Category:** General / Contact  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** social media, facebook, twitter, linkedin, youtube, whatsapp

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- When was PMI Chennai Chapter founded?
- What is PMICC's motto or guiding philosophy?

---


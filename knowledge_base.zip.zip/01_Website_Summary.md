# PMI Chennai Chapter (pmichennai.org) — Website Summary

**Crawl scope note:** This knowledge base was built from a targeted crawl of 4 pages (Home, Membership, Certification & Training, Volunteering Overview) rather than the full site. The site's navigation reveals ~25+ additional pages (Awards & Accolades, Outreach, Academic Outreach, Corporate Outreach, Chapter Students Club, Chapter Ambassador Program, Enroll as Volunteer, Volunteer Recognitions, Volunteer Voice, Chapter Events, Chapter Highlights/News, Events Calendar, Events Gallery, Career++, Newsletter, PMI AI Assistant, Coimbatore Branch, Social Impact, Women Empowerment, and individual certification pages for PMP/ACP/PgMP/Primavera/Design Thinking/Power BI/Blockchain/AI/MS Project) that were identified via the nav menu but **not yet crawled and extracted**. See `02_All_Pages.md` for the full list with status. Every fact below is sourced from an actually-fetched page — nothing is inferred or guessed.

## Organization
- **Name:** PMI Chennai Chapter (PMICC)
- **Parent org:** Project Management Institute (PMI), Newtown Square, Pennsylvania, USA
- **Legal status:** Registered society under the Tamil Nadu Registration of Societies Act; not-for-profit, tax-exempt membership society
- **Founded:** 2002, by a group led by Dr. P. N. Sridharan
- **Members:** 1,500+ (per volunteering overview page)
- **Registered address:** 715-A, 7th Floor, Spencer Plaza, Suite No.1182, Anna Salai, Chennai – 600 002
- **Phone:** +91 87785 66932
- **President:** Vijay Narayanan (president@pmi-chennai.org)
- **Secretary/EVP:** Vijay Mohan Gandhi (Secretary@pmi-chennai.org)

## Core Offerings
1. Membership (via PMI global signup, Chennai Chapter)
2. Certification & training programs (PMP, PMI-ACP, PgMP, and skills workshops)
3. Volunteering / leadership development
4. Events, conferences (e.g. Sangamam), knowledge-sharing sessions
5. Outreach (academic and corporate)
6. Social impact and women-empowerment initiatives
7. Coimbatore branch activity

## Governance Structure Observed
Board of Directors (President, EVP/Secretary, and VPs for Finance, Governance, Programs, Outreach, Volunteer Development, Women Engagement, Technology, Marketing & Communications, Membership, Social Impact), supported by a large Associate Vice President (AVP) layer across the same portfolios plus Outreach Advocacy.

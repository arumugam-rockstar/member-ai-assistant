# Knowledge Graph — PMI Chennai Chapter

```
PMI Chennai Chapter (PMICC)
├── Governance
│   ├── Legal status (Tamil Nadu Registered Society, non-profit)
│   ├── Board of Directors
│   │   ├── President — Vijay Narayanan
│   │   ├── EVP & Secretary — Vijay Mohan Gandhi
│   │   └── VPs (Finance, Governance, Programs, Outreach, Volunteer Dev.,
│   │        Women Engagement, Technology, Marketing & Comms, Membership, Social Impact)
│   └── Associate Vice Presidents (AVP layer, same portfolios + Outreach Advocacy)
├── Membership
│   ├── How to join → PMI global signup (Chennai Chapter)
│   ├── Onboarding → 3B Journey (Belong / Believe / Become, 30-60-90 days)
│   ├── Benefits → PMBOK access, PMI Infinity, eLearning, cert. discounts, global jobs
│   ├── Community size → 1,500+ members
│   └── FAQ → linked to PMI global membership FAQ
├── Certification & Training
│   ├── Programs → PMP, PMI-ACP, PgMP, Oracle Primavera, Design Thinking,
│   │        Power BI, Leadership (Lead Up), Blockchain, AI Workshop, MS Project
│   ├── Registration contact → vpcertification@pmi-chennai.org
│   ├── Fees → program-specific (member vs non-member rates); confirm current pricing directly
│   └── PDUs → awarded per workshop (e.g. 6.0 PDUs on several archived workshops)
├── Volunteering
│   ├── Eligibility → open to PMICC members
│   ├── Benefits → leadership development, networking, PMI membership perks
│   ├── Enrollment → dedicated "Enroll as Volunteer" page
│   └── Recognition → "Volunteer Recognitions" and "Volunteer Voice" pages
├── Events
│   ├── Chapter Events / Events Calendar / Events Gallery
│   ├── Flagship conference → Sangamam (referenced in Board bios, e.g. Sangamam24)
│   └── Regional events → Kovai/Coimbatore Sangamam
├── Outreach
│   ├── Academic Outreach → Chapter Students Club, Chapter Ambassador Program
│   └── Corporate Outreach
├── Regional Presence
│   └── Coimbatore Branch ("Kovai")
└── Contact
    ├── Registered office → Spencer Plaza, Anna Salai, Chennai – 600002
    ├── Phone → +91 87785 66932
    └── Social → Facebook, Twitter/X, LinkedIn, YouTube, WhatsApp
```

# 04 Membership FAQ

### Q1. How do I become a PMI Chennai Chapter member?

To become a PMICC member, you sign up through PMI's official global membership shop page and select the Chennai Chapter. The chapter's website links directly to PMI's chapter-membership page for the Chennai Chapter for this purpose.

**Category:** Membership / How to Join  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** how to join, become a member, membership signup

**Related questions:**
- What is the PMICC 3B Journey for new members?
- When does PMICC run its virtual onboarding session for new members?
- What benefits does PMI membership provide?

---

### Q2. What is the PMICC 3B Journey for new members?

The 3B Journey is PMICC's 30-60-90 day plan for onboarding new members: 'Belong' (first 30 days — automated welcome email, added to relevant channels), 'Believe' (first 60 days — a virtual onboarding session and an assigned buddy, including introduction to a mentorship track called Project Thunai/Companion based on the member's interest), and 'Become' (first 90 days — encouragement to attend chapter events and take up volunteering opportunities, plus a chance to connect in person quarterly).

**Category:** Membership / Onboarding  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** 3B plan, onboarding, belong believe become, new member

**Related questions:**
- How do I become a PMI Chennai Chapter member?
- When does PMICC run its virtual onboarding session for new members?
- What benefits does PMI membership provide?

---

### Q3. When does PMICC run its virtual onboarding session for new members?

PMICC runs its virtual onboarding session every second Wednesday evening.

**Category:** Membership / Onboarding  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** onboarding session, schedule, second Wednesday

**Related questions:**
- How do I become a PMI Chennai Chapter member?
- What is the PMICC 3B Journey for new members?
- What benefits does PMI membership provide?

---

### Q4. What benefits does PMI membership provide?

According to PMICC's membership page, PMI membership benefits include access to the PMBOK standards, PMI Infinity, webinars, eLearning resources, certification discounts, and global job opportunities. PMICC further supplements this with chapter-level initiatives: knowledge sharing, mentoring programs, workshops, conferences, leadership development, community engagement, and networking/mentorship platforms.

**Category:** Membership / Benefits  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** membership benefits, PMBOK, PMI Infinity, eLearning, certification discounts

**Related questions:**
- How do I become a PMI Chennai Chapter member?
- What is the PMICC 3B Journey for new members?
- When does PMICC run its virtual onboarding session for new members?

---

### Q5. How much does PMI Chennai Chapter membership cost?

The certification-training page (an older, archived listing) mentions chapter membership can be obtained for US $15 as part of a specific training promotion, but this figure is tied to a historical workshop offer, not a current general membership fee schedule. This information is not available on the PMI Chennai website (based on the pages crawled). For the current, authoritative membership fee, use the 'Become a Member' link to PMI's official chapter-membership shop page.

**Category:** Membership / Fees  
**Source:** [Certification & Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** Medium  
**Tags:** membership fee, cost, price, US $15

**Related questions:**
- How do I become a PMI Chennai Chapter member?
- What is the PMICC 3B Journey for new members?
- When does PMICC run its virtual onboarding session for new members?

---

### Q6. Where can I find more membership FAQs?

PMICC's membership page links out to PMI's own global membership FAQ page (pmi.org/membership/faq) for further questions.

**Category:** Membership / FAQ  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** membership FAQ, PMI FAQ

**Related questions:**
- How do I become a PMI Chennai Chapter member?
- What is the PMICC 3B Journey for new members?
- When does PMICC run its virtual onboarding session for new members?

---

### Q7. How many members does PMI Chennai Chapter have?

Per the volunteering overview page, PMI Chennai Chapter has over 1,500 members and is growing.

**Category:** Membership / Community Size  
**Source:** [Join Us - Volunteering Overview](https://www.pmichennai.org/join-us-volunteering-overview/)  
**Confidence:** High  
**Tags:** member count, 1500 members, community size

**Related questions:**
- How do I become a PMI Chennai Chapter member?
- What is the PMICC 3B Journey for new members?
- When does PMICC run its virtual onboarding session for new members?

---


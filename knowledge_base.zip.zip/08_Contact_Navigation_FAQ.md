# 08 Contact Navigation FAQ

### Q1. What sections does the PMI Chennai Chapter website have?

The main navigation includes: Home; About Us (About Chapter, Chapter Executives, Additional Chapter Executives, Awards and Accolades, PMI Chennai Chapter Membership); Certification & Training (PMP, PMI-ACP, PgMP, Oracle Primavera Workshop, Design Thinking, Power BI, Leadership 'Lead Up', Blockchain, AI Workshop, MS Project Essentials); Outreach (Overview, Corporate Outreach, Academic Outreach, Chapter Students Club, Chapter Ambassador Program); Volunteering (Overview, Enroll as Volunteer, Volunteer Recognitions, Volunteer Voice); and a 'More' menu (Chapter Events, Chapter Highlights/News, Events Calendar, Events Gallery, Career++, Newsletter, PMI AI Assistant, Coimbatore Branch, Social Impact, Women Empowerment).

**Category:** Website Navigation / Site Map  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** site map, navigation, menu structure

**Related questions:**
- Does PMI Chennai Chapter have a branch outside Chennai?

---

### Q2. Does PMI Chennai Chapter have a branch outside Chennai?

Yes, the navigation lists a 'PMI Chennai Chapter - Coimbatore Branch' page, indicating the chapter also has activity/presence in Coimbatore (referred to informally on the site as 'Kovai').

**Category:** Website Navigation / Regional Branch  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** Coimbatore, Kovai, branch, regional presence

**Related questions:**
- What sections does the PMI Chennai Chapter website have?

---


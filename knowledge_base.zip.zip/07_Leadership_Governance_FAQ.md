# 07 Leadership Governance FAQ

### Q1. Who is the President of PMI Chennai Chapter?

Vijay Narayanan is the President of PMI Chennai Chapter. He is a senior IT professional with over 24 years of experience, currently a senior manager of Engineering at M&G Investments. He obtained his PMP certification in 2015 and has been on the chapter board since 2019. Contact: president@pmi-chennai.org, +91 99404 38413.

**Category:** Leadership / Board of Directors  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** president, Vijay Narayanan, board of directors

**Related questions:**
- Who is the Secretary of PMI Chennai Chapter?
- Who are the Vice Presidents on the PMI Chennai Chapter board?
- Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

---

### Q2. Who is the Secretary of PMI Chennai Chapter?

Vijay Mohan Gandhi is the Executive Vice President and Secretary. He is a technology and delivery leader with 25+ years of experience, currently Domain Head at Ericsson. A PMI member since 2011 and volunteer since 2016. Contact: Secretary@pmi-chennai.org, +91 97910 41947.

**Category:** Leadership / Board of Directors  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** secretary, Vijay Mohan Gandhi

**Related questions:**
- Who is the President of PMI Chennai Chapter?
- Who are the Vice Presidents on the PMI Chennai Chapter board?
- Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

---

### Q3. Who are the Vice Presidents on the PMI Chennai Chapter board?

The PMICC Board of Directors' Vice Presidents (as listed on the site) include: Haribabuji Harikrishnan (Finance), Sundaram Muthukumarasamy (Governance), Dr. Dinesh Babu Thavamani (Programs), Dr. B. Shyam Sundar (Outreach), Jahnavi Tirumalasetty (Volunteer Development), Swetha Surendran (Women Engagement), Arumugam Mariappan (Technology), Muthukumaran Sowndhararajan (Marketing & Communications), Vickram S K (Membership), and Krishnakumar Kesavan (Social Impact). Each has a dedicated chapter email address (e.g. vpfinance@pmi-chennai.org, vpgovernance@pmi-chennai.org).

**Category:** Leadership / Board of Directors  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** vice president, VP, board, governance, finance

**Related questions:**
- Who is the President of PMI Chennai Chapter?
- Who is the Secretary of PMI Chennai Chapter?
- Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

---

### Q4. Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

Yes. The site lists numerous Associate Vice Presidents across portfolios including Women Engagement, Technology, Marketing, Outreach, Outreach Advocacy, Social Impact, Programs, Membership, and Volunteering — for example Latha Vishwanath (AVP Women Engagement), Magesh Rajagopalan (AVP Technology), Mohammed Ejaaz Basheer (AVP Marketing), Ruby S (AVP Outreach), Srivikraman M (AVP Outreach Advocacy), Victor Jacob Damodaram (AVP Social Impact), Vijayakumar VK (AVP Programs), Babu Manivelu and Mahalingam Athmanathan (AVP Membership), Geetha Kathiresan (AVP Social Impact - Coimbatore), Radha Somasundaram (AVP Programs), Sankar Ganesh S (AVP Volunteering), Sridhar Thanikachalam (AVP Programs), and Preethi S (AVP Marketing).

**Category:** Leadership / Chapter Executives  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** AVP, associate vice president, chapter executives

**Related questions:**
- Who is the President of PMI Chennai Chapter?
- Who is the Secretary of PMI Chennai Chapter?
- Who are the Vice Presidents on the PMI Chennai Chapter board?

---

### Q5. Is PMI Chennai Chapter a registered non-profit?

Yes. PMICC is a registered society under the Tamil Nadu Registration of Societies Act, and operates as a not-for-profit, tax-exempt membership society and a chartered component of PMI (headquartered in Newtown Square, Pennsylvania, USA).

**Category:** Governance / Legal Status  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** non-profit, registered society, tax-exempt, legal status


---


# 03 Master FAQ

### Q1. What is PMI Chennai Chapter (PMICC)?

The PMI Chennai Chapter (PMICC) is a non-profit oriented chartered component of the Project Management Institute (PMI), which is headquartered in Newtown Square, Pennsylvania, USA. PMICC is registered as a society under the Tamil Nadu Registration of Societies Act, making it a not-for-profit, tax-exempt membership society.

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** about, PMICC, non-profit, PMI

**Related questions:**
- When was PMI Chennai Chapter founded?
- What is PMICC's motto or guiding philosophy?
- What is the vision of PMI Chennai Chapter?

---

### Q2. When was PMI Chennai Chapter founded?

PMICC was founded in 2002, when a group of visionaries headed by Dr. P. N. Sridharan initiated a new PMI-affiliated chapter in Chennai.

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** history, inception, 2002, founding

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- What is PMICC's motto or guiding philosophy?
- What is the vision of PMI Chennai Chapter?

---

### Q3. What is PMICC's motto or guiding philosophy?

PMICC's motto is to be an organisation 'of the members', 'by the members' and 'for the members', with an emphasis on serving Academia, Business, and Community (the 'ABCs').

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** motto, principles, goal

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- When was PMI Chennai Chapter founded?
- What is the vision of PMI Chennai Chapter?

---

### Q4. What is the vision of PMI Chennai Chapter?

PMICC's vision is Regional Excellence in the Practice of Project Management through modern, structured management-of-projects concepts that are widely recognized and consistently applied.

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** vision

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- When was PMI Chennai Chapter founded?
- What is PMICC's motto or guiding philosophy?

---

### Q5. What is the mission of PMI Chennai Chapter?

PMICC's mission is to: (1) assist in improving the understanding and ability of experienced and new project management practitioners and customers, (2) assist in improving the maturity and quality of project management practitioners, (3) create awareness in the younger generation at school and college levels, and (4) propagate generally accepted project management approaches and the guide to PMBOK.

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** mission

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- When was PMI Chennai Chapter founded?
- What is PMICC's motto or guiding philosophy?

---

### Q6. Where is the PMI Chennai Chapter office located?

PMICC's registered address is: Project Management Institute Chennai Chapter, 715-A, 7th Floor, Spencer Plaza, Suite No.1182, Anna Salai, Chennai - 600 002.

**Category:** General / Contact  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** office, address, location, Spencer Plaza

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- When was PMI Chennai Chapter founded?
- What is PMICC's motto or guiding philosophy?

---

### Q7. What is PMI Chennai Chapter's phone number?

The chapter's listed mobile number on the homepage is +91 87785 66932.

**Category:** General / Contact  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** phone, contact number

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- When was PMI Chennai Chapter founded?
- What is PMICC's motto or guiding philosophy?

---

### Q8. How can I contact PMI Chennai Chapter for volunteering, training, or website queries?

For chapter volunteering queries, email vpvolunteers@pmi-chennai.org. For training program queries, email vpprograms@pmi-chennai.org. For chapter website queries, email vptechnology@pmi-chennai.org.

**Category:** General / Contact  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** contact, email, queries, volunteering contact, training contact, website contact

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- When was PMI Chennai Chapter founded?
- What is PMICC's motto or guiding philosophy?

---

### Q9. What are PMI Chennai Chapter's social media handles?

PMICC is present on Facebook (facebook.com/pmichennai), Twitter/X (@pmichennai), LinkedIn (linkedin.com/school/pmichennai), YouTube, and WhatsApp (a WhatsApp channel link is provided on the site).

**Category:** General / Contact  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** social media, facebook, twitter, linkedin, youtube, whatsapp

**Related questions:**
- What is PMI Chennai Chapter (PMICC)?
- When was PMI Chennai Chapter founded?
- What is PMICC's motto or guiding philosophy?

---

### Q10. Who is the President of PMI Chennai Chapter?

Vijay Narayanan is the President of PMI Chennai Chapter. He is a senior IT professional with over 24 years of experience, currently a senior manager of Engineering at M&G Investments. He obtained his PMP certification in 2015 and has been on the chapter board since 2019. Contact: president@pmi-chennai.org, +91 99404 38413.

**Category:** Leadership / Board of Directors  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** president, Vijay Narayanan, board of directors

**Related questions:**
- Who is the Secretary of PMI Chennai Chapter?
- Who are the Vice Presidents on the PMI Chennai Chapter board?
- Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

---

### Q11. Who is the Secretary of PMI Chennai Chapter?

Vijay Mohan Gandhi is the Executive Vice President and Secretary. He is a technology and delivery leader with 25+ years of experience, currently Domain Head at Ericsson. A PMI member since 2011 and volunteer since 2016. Contact: Secretary@pmi-chennai.org, +91 97910 41947.

**Category:** Leadership / Board of Directors  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** secretary, Vijay Mohan Gandhi

**Related questions:**
- Who is the President of PMI Chennai Chapter?
- Who are the Vice Presidents on the PMI Chennai Chapter board?
- Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

---

### Q12. Who are the Vice Presidents on the PMI Chennai Chapter board?

The PMICC Board of Directors' Vice Presidents (as listed on the site) include: Haribabuji Harikrishnan (Finance), Sundaram Muthukumarasamy (Governance), Dr. Dinesh Babu Thavamani (Programs), Dr. B. Shyam Sundar (Outreach), Jahnavi Tirumalasetty (Volunteer Development), Swetha Surendran (Women Engagement), Arumugam Mariappan (Technology), Muthukumaran Sowndhararajan (Marketing & Communications), Vickram S K (Membership), and Krishnakumar Kesavan (Social Impact). Each has a dedicated chapter email address (e.g. vpfinance@pmi-chennai.org, vpgovernance@pmi-chennai.org).

**Category:** Leadership / Board of Directors  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** vice president, VP, board, governance, finance

**Related questions:**
- Who is the President of PMI Chennai Chapter?
- Who is the Secretary of PMI Chennai Chapter?
- Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

---

### Q13. Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

Yes. The site lists numerous Associate Vice Presidents across portfolios including Women Engagement, Technology, Marketing, Outreach, Outreach Advocacy, Social Impact, Programs, Membership, and Volunteering — for example Latha Vishwanath (AVP Women Engagement), Magesh Rajagopalan (AVP Technology), Mohammed Ejaaz Basheer (AVP Marketing), Ruby S (AVP Outreach), Srivikraman M (AVP Outreach Advocacy), Victor Jacob Damodaram (AVP Social Impact), Vijayakumar VK (AVP Programs), Babu Manivelu and Mahalingam Athmanathan (AVP Membership), Geetha Kathiresan (AVP Social Impact - Coimbatore), Radha Somasundaram (AVP Programs), Sankar Ganesh S (AVP Volunteering), Sridhar Thanikachalam (AVP Programs), and Preethi S (AVP Marketing).

**Category:** Leadership / Chapter Executives  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** AVP, associate vice president, chapter executives

**Related questions:**
- Who is the President of PMI Chennai Chapter?
- Who is the Secretary of PMI Chennai Chapter?
- Who are the Vice Presidents on the PMI Chennai Chapter board?

---

### Q14. Is PMI Chennai Chapter a registered non-profit?

Yes. PMICC is a registered society under the Tamil Nadu Registration of Societies Act, and operates as a not-for-profit, tax-exempt membership society and a chartered component of PMI (headquartered in Newtown Square, Pennsylvania, USA).

**Category:** Governance / Legal Status  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** non-profit, registered society, tax-exempt, legal status


---

### Q15. How do I become a PMI Chennai Chapter member?

To become a PMICC member, you sign up through PMI's official global membership shop page and select the Chennai Chapter. The chapter's website links directly to PMI's chapter-membership page for the Chennai Chapter for this purpose.

**Category:** Membership / How to Join  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** how to join, become a member, membership signup

**Related questions:**
- What is the PMICC 3B Journey for new members?
- When does PMICC run its virtual onboarding session for new members?
- What benefits does PMI membership provide?

---

### Q16. What is the PMICC 3B Journey for new members?

The 3B Journey is PMICC's 30-60-90 day plan for onboarding new members: 'Belong' (first 30 days — automated welcome email, added to relevant channels), 'Believe' (first 60 days — a virtual onboarding session and an assigned buddy, including introduction to a mentorship track called Project Thunai/Companion based on the member's interest), and 'Become' (first 90 days — encouragement to attend chapter events and take up volunteering opportunities, plus a chance to connect in person quarterly).

**Category:** Membership / Onboarding  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** 3B plan, onboarding, belong believe become, new member

**Related questions:**
- How do I become a PMI Chennai Chapter member?
- When does PMICC run its virtual onboarding session for new members?
- What benefits does PMI membership provide?

---

### Q17. When does PMICC run its virtual onboarding session for new members?

PMICC runs its virtual onboarding session every second Wednesday evening.

**Category:** Membership / Onboarding  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** onboarding session, schedule, second Wednesday

**Related questions:**
- How do I become a PMI Chennai Chapter member?
- What is the PMICC 3B Journey for new members?
- What benefits does PMI membership provide?

---

### Q18. What benefits does PMI membership provide?

According to PMICC's membership page, PMI membership benefits include access to the PMBOK standards, PMI Infinity, webinars, eLearning resources, certification discounts, and global job opportunities. PMICC further supplements this with chapter-level initiatives: knowledge sharing, mentoring programs, workshops, conferences, leadership development, community engagement, and networking/mentorship platforms.

**Category:** Membership / Benefits  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** membership benefits, PMBOK, PMI Infinity, eLearning, certification discounts

**Related questions:**
- How do I become a PMI Chennai Chapter member?
- What is the PMICC 3B Journey for new members?
- When does PMICC run its virtual onboarding session for new members?

---

### Q19. How much does PMI Chennai Chapter membership cost?

The certification-training page (an older, archived listing) mentions chapter membership can be obtained for US $15 as part of a specific training promotion, but this figure is tied to a historical workshop offer, not a current general membership fee schedule. This information is not available on the PMI Chennai website (based on the pages crawled). For the current, authoritative membership fee, use the 'Become a Member' link to PMI's official chapter-membership shop page.

**Category:** Membership / Fees  
**Source:** [Certification & Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** Medium  
**Tags:** membership fee, cost, price, US $15

**Related questions:**
- How do I become a PMI Chennai Chapter member?
- What is the PMICC 3B Journey for new members?
- When does PMICC run its virtual onboarding session for new members?

---

### Q20. Where can I find more membership FAQs?

PMICC's membership page links out to PMI's own global membership FAQ page (pmi.org/membership/faq) for further questions.

**Category:** Membership / FAQ  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** membership FAQ, PMI FAQ

**Related questions:**
- How do I become a PMI Chennai Chapter member?
- What is the PMICC 3B Journey for new members?
- When does PMICC run its virtual onboarding session for new members?

---

### Q21. How many members does PMI Chennai Chapter have?

Per the volunteering overview page, PMI Chennai Chapter has over 1,500 members and is growing.

**Category:** Membership / Community Size  
**Source:** [Join Us - Volunteering Overview](https://www.pmichennai.org/join-us-volunteering-overview/)  
**Confidence:** High  
**Tags:** member count, 1500 members, community size

**Related questions:**
- How do I become a PMI Chennai Chapter member?
- What is the PMICC 3B Journey for new members?
- When does PMICC run its virtual onboarding session for new members?

---

### Q22. Who can volunteer with PMI Chennai Chapter?

The site frames volunteering as open to members of PMICC — both those new to project management and experienced industry veterans. All chapter activities are planned, organized, and led by member volunteers.

**Category:** Volunteering / Overview  
**Source:** [Join Us - Volunteering Overview](https://www.pmichennai.org/join-us-volunteering-overview/)  
**Confidence:** High  
**Tags:** who can volunteer, volunteer eligibility

**Related questions:**
- What are the benefits of volunteering with PMI Chennai Chapter?
- How do I sign up to volunteer at PMI Chennai Chapter?

---

### Q23. What are the benefits of volunteering with PMI Chennai Chapter?

Volunteering lets members develop leadership skills (all chapter activities are planned and led by volunteering members), network with peers across industries, and gain the broader benefits of PMI membership — including members-only services and discounts, complimentary publications, and continuing education opportunities.

**Category:** Volunteering / Benefits  
**Source:** [Join Us - Volunteering Overview](https://www.pmichennai.org/join-us-volunteering-overview/)  
**Confidence:** High  
**Tags:** volunteer benefits, leadership development, networking

**Related questions:**
- Who can volunteer with PMI Chennai Chapter?
- How do I sign up to volunteer at PMI Chennai Chapter?

---

### Q24. How do I sign up to volunteer at PMI Chennai Chapter?

The chapter's navigation menu includes a dedicated 'Enroll as Volunteer' page (Volunteering > Enroll as Volunteer) for signing up. This information is not available on the PMI Chennai website (based on the pages crawled). regarding the exact steps on that specific enrollment page, since it was not part of the pages crawled in this session — check https://www.pmichennai.org/volunteeringopportunities/ directly.

**Category:** Volunteering / How to Join  
**Source:** [Join Us - Volunteering Overview](https://www.pmichennai.org/join-us-volunteering-overview/)  
**Confidence:** Medium  
**Tags:** volunteer signup, enroll, how to volunteer

**Related questions:**
- Who can volunteer with PMI Chennai Chapter?
- What are the benefits of volunteering with PMI Chennai Chapter?

---

### Q25. What certification and training programs does PMI Chennai Chapter offer?

PMICC's Certification & Training page lists preparatory training for PMI-ACP (via 'ACP & Beyond'), a PgMP orientation program, and hands-on workshops including Microsoft Project Essentials, JIRA Basics, ProjectLibre Essentials, and Primavera Essentials. The main site navigation also lists separate pages for PMP Certification Training, PMI ACP Certification Training, PgMP Certification Training, an Oracle Primavera Workshop, Design Thinking for Project Managers, a Power BI workshop, a leadership workshop ('Lead Up'), an Introduction to Blockchain Technology, an Artificial Intelligence Workshop, and Essentials of Project Management Using Microsoft Project.

**Category:** Certification / Programs Offered  
**Source:** [Certification & Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** High  
**Tags:** certification programs, PMP, PMI-ACP, PgMP, workshops, training catalog

**Related questions:**
- Who do I contact to register for PMICC training or certification programs?
- How much did the PgMP one-day training program cost?
- How do I pay for a PMICC training program by bank transfer?

---

### Q26. Who do I contact to register for PMICC training or certification programs?

Registration and certification-training queries go to vpcertification@pmi-chennai.org (also referenced historically as Training@pmi-chennai.org for payment confirmations).

**Category:** Certification / Who To Contact  
**Source:** [Certification & Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** High  
**Tags:** registration, training contact, vpcertification

**Related questions:**
- What certification and training programs does PMI Chennai Chapter offer?
- How much did the PgMP one-day training program cost?
- How do I pay for a PMICC training program by bank transfer?

---

### Q27. How much did the PgMP one-day training program cost?

In an archived listing on the site, the 1-Day PgMP Training Program was priced at Rs. 4,000 + 18% GST for PMI Chennai members and Rs. 6,000 + 18% GST for non-members. This is historical/example pricing from a past batch, not a standing current fee — always confirm current pricing directly with vpcertification@pmi-chennai.org.

**Category:** Certification / Fees (Historical Example)  
**Source:** [Certification & Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** Medium  
**Tags:** PgMP fee, training cost, pricing example

**Related questions:**
- What certification and training programs does PMI Chennai Chapter offer?
- Who do I contact to register for PMICC training or certification programs?
- How do I pay for a PMICC training program by bank transfer?

---

### Q28. How do I pay for a PMICC training program by bank transfer?

An archived workshop listing gives these bank transfer details: Account Name: PMI Chennai Chapter; Bank: Kotak Mahindra Bank; Branch: Adyar; Account type: Current account; Account No: 5711125967; IFSC Code: KKBK0000463. After transferring, participants were asked to email a screenshot of the transaction to Training@pmi-chennai.org / vpcertification@pmi-chennai.org for reconciliation. Confirm these details are still current before making a payment, since this was found on an older archived page.

**Category:** Certification / Payment  
**Source:** [Certification & Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** Medium  
**Tags:** bank transfer, payment, IFSC, account number

**Related questions:**
- What certification and training programs does PMI Chennai Chapter offer?
- Who do I contact to register for PMICC training or certification programs?
- How much did the PgMP one-day training program cost?

---

### Q29. Do PMICC workshops offer PDUs?

Yes, several archived workshop listings (e.g. Microsoft Project 2016 Essentials, JIRA, Project Libre Essentials, Primavera Essentials) awarded 6.0 PDUs each. PDU amounts vary by workshop; check the specific event page for current figures.

**Category:** Certification / PDUs  
**Source:** [Certification & Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** High  
**Tags:** PDU, professional development units, 6.0 PDUs

**Related questions:**
- What certification and training programs does PMI Chennai Chapter offer?
- Who do I contact to register for PMICC training or certification programs?
- How much did the PgMP one-day training program cost?

---

### Q30. What sections does the PMI Chennai Chapter website have?

The main navigation includes: Home; About Us (About Chapter, Chapter Executives, Additional Chapter Executives, Awards and Accolades, PMI Chennai Chapter Membership); Certification & Training (PMP, PMI-ACP, PgMP, Oracle Primavera Workshop, Design Thinking, Power BI, Leadership 'Lead Up', Blockchain, AI Workshop, MS Project Essentials); Outreach (Overview, Corporate Outreach, Academic Outreach, Chapter Students Club, Chapter Ambassador Program); Volunteering (Overview, Enroll as Volunteer, Volunteer Recognitions, Volunteer Voice); and a 'More' menu (Chapter Events, Chapter Highlights/News, Events Calendar, Events Gallery, Career++, Newsletter, PMI AI Assistant, Coimbatore Branch, Social Impact, Women Empowerment).

**Category:** Website Navigation / Site Map  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** site map, navigation, menu structure

**Related questions:**
- Does PMI Chennai Chapter have a branch outside Chennai?

---

### Q31. Does PMI Chennai Chapter have a branch outside Chennai?

Yes, the navigation lists a 'PMI Chennai Chapter - Coimbatore Branch' page, indicating the chapter also has activity/presence in Coimbatore (referred to informally on the site as 'Kovai').

**Category:** Website Navigation / Regional Branch  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** Coimbatore, Kovai, branch, regional presence

**Related questions:**
- What sections does the PMI Chennai Chapter website have?

---


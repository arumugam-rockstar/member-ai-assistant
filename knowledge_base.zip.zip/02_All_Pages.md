# All Pages — Crawl Status

## Crawled & Extracted (source of truth for this knowledge base)

### Home
- **URL:** https://www.pmichennai.org/
- **Navigation Path:** Home
- **Category:** General / About
- **Last Updated (per site metadata):** 2026-07-06
- **Summary:** Homepage of the PMI Chennai Chapter (PMICC). Introduces the chapter as a non-profit, chartered component of the Project Management Institute (PMI), headquartered in Newtown Square, Pennsylvania, USA. Registered as a society under the Tamil Nadu Registration of Societies Act (not-for-profit, tax-exempt membership society). Covers chapter inception, vision, mission, upcoming events, recent news, full Board of Directors / chapter executives, additional chapter executives, photo gallery, academic and corporate partners, and contact details.
- **Contacts found:** President: Vijay Narayanan - president@pmi-chennai.org, +91 99404 38413 | Registered office: 715-A, 7th Floor, Spencer Plaza, Suite No.1182, Anna Salai, Chennai - 600 002, Mobile: +91 87785 66932
- **Keywords:** PMI Chennai, PMICC, about chapter, board of directors, chapter executives, vision, mission, history, inception, gallery, partners

### PMI Chennai Chapter Membership
- **URL:** https://www.pmichennai.org/pmicc-membership/
- **Navigation Path:** Home > About Us > PMI Chennai Chapter Membership
- **Category:** Membership
- **Last Updated (per site metadata):** 2026-05-20
- **Summary:** Describes PMICC's member-onboarding '3B Journey' (Belong-Believe-Become, a 30-60-90 day plan) and links members to PMI's global membership signup for the Chennai Chapter.
- **Contacts found:** General site contact per footer: 715-A, 7th Floor, Spencer Plaza, Suite No.1182, Mount Road, Anna Salai, Chennai - 600 002
- **Keywords:** membership, join PMI Chennai, 3B plan, onboarding, belong believe become, mentorship, Project Thunai

### Certification & Training
- **URL:** https://www.pmichennai.org/certification-training/
- **Navigation Path:** Home > Certification & Training
- **Category:** Certification & Training
- **Last Updated (per site metadata):** 2024-03-12
- **Summary:** Lists PMICC's training and certification preparation offerings (PMI-ACP, PgMP orientation, Microsoft Project, JIRA, ProjectLibre, Primavera). Contains archived workshop listings with historical fee structures, schedules, and registration contacts (content dated 2021-2022, retained on the page as of the last crawl).
- **Contacts found:** Certification/training registration: vpcertification@pmi-chennai.org / Training@pmi-chennai.org
- **Keywords:** PMP, PMI-ACP, PgMP, certification training, workshop, JIRA, Primavera, Microsoft Project, ProjectLibre, PDUs, fees

### Join Us - Volunteering Overview
- **URL:** https://www.pmichennai.org/join-us-volunteering-overview/
- **Navigation Path:** Home > Volunteering > Overview
- **Category:** Volunteering
- **Last Updated (per site metadata):** 2024-03-07
- **Summary:** Explains why to volunteer/join PMICC: notes PMICC has 1500+ members, describes chapter leadership development opportunities, and lists the general benefits of PMI membership (best practices, professional values, member-only services and discounts, publications, continuing education).
- **Contacts found:** General site contact per footer
- **Keywords:** volunteering, volunteer benefits, leadership development, 1500 members, PMI membership benefits

## Identified via navigation menu but NOT yet crawled/extracted

- [ ] **Awards and Accolades** — https://www.pmichennai.org/awards-own-by-pmi-chennai/
- [ ] **PMP Certification Training** — https://www.pmichennai.org/pmp/
- [ ] **PMI ACP Certification Training** — https://www.pmichennai.org/acp/
- [ ] **PgMP Certification Training** — https://www.pmichennai.org/pgmp-certification-training/
- [ ] **Oracle Primavera Workshop** — https://www.pmichennai.org/oracle-primavera-workshop/
- [ ] **Design Thinking for Project Managers** — https://www.pmichennai.org/design-thinking/
- [ ] **Leading with Purpose (Lead Up)** — https://www.pmichennai.org/lead-up/
- [ ] **Essentials of PM Using MS Project** — https://www.pmichennai.org/essentials-of-project-management-using-microsoft-project/
- [ ] **Outreach – An Overview** — https://www.pmichennai.org/outreach/
- [ ] **Corporate Outreach** — https://www.pmichennai.org/corporate-outreach/
- [ ] **Academic Outreach** — https://www.pmichennai.org/academic-outreach/
- [ ] **Chapter Students Club** — https://www.pmichennai.org/chapter-students-club/
- [ ] **Chapter Ambassador Program** — https://www.pmichennai.org/chapter-ambassador-program/
- [ ] **Enroll as Volunteer** — https://www.pmichennai.org/volunteeringopportunities/
- [ ] **Volunteer Recognitions** — https://www.pmichennai.org/volunteer-recognitions/
- [ ] **Volunteer Voice** — https://www.pmichennai.org/volunteer-voice/
- [ ] **Chapter Events** — https://www.pmichennai.org/chapter-events/
- [ ] **Chapter Highlights / News** — https://www.pmichennai.org/chapter-news/
- [ ] **Events Calendar** — https://www.pmichennai.org/events-calendar/
- [ ] **Events Gallery** — https://www.pmichennai.org/events-gallery/
- [ ] **Career++** — https://www.pmichennai.org/career/
- [ ] **Newsletter** — https://www.pmichennai.org/newsletter/
- [ ] **PMI AI Assistant** — https://www.pmichennai.org/pmi-ai-assitant/
- [ ] **PMI Chennai Chapter – Coimbatore Branch** — https://www.pmichennai.org/pmicc-coimbatorebranch/
- [ ] **Social Impact** — https://www.pmichennai.org/socialimpact/
- [ ] **Women Empowerment** — https://www.pmichennai.org/women-empowerment/

*To extend this knowledge base, fetch each remaining URL and re-run the extraction pipeline; the data.json structure supports incremental additions.*

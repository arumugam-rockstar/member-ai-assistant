# 03 Master FAQ

### Q1. What is PMI Chennai Chapter (PMICC)?

The PMI Chennai Chapter (PMICC) is a non-profit oriented chartered component of the Project Management Institute (PMI), which is headquartered in Newtown Square, Pennsylvania, USA. PMICC is registered as a society under the Tamil Nadu Registration of Societies Act, making it a not-for-profit, tax-exempt membership society.

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** about, PMICC, non-profit, PMI

**Related questions:**

* When was PMI Chennai Chapter founded?
* What is PMICC's motto or guiding philosophy?
* What is the vision of PMI Chennai Chapter?

\---

### Q2. When was PMI Chennai Chapter founded?

PMICC was founded in 2002, when a group of visionaries headed by Dr. P. N. Sridharan initiated a new PMI-affiliated chapter in Chennai.

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** history, inception, 2002, founding

**Related questions:**

* What is PMI Chennai Chapter (PMICC)?
* What is PMICC's motto or guiding philosophy?
* What is the vision of PMI Chennai Chapter?

\---

### Q3. What is PMICC's motto or guiding philosophy?

PMICC's motto is to be an organisation 'of the members', 'by the members' and 'for the members', with an emphasis on serving Academia, Business, and Community (the 'ABCs').

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** motto, principles, goal

**Related questions:**

* What is PMI Chennai Chapter (PMICC)?
* When was PMI Chennai Chapter founded?
* What is the vision of PMI Chennai Chapter?

\---

### Q4. What is the vision of PMI Chennai Chapter?

PMICC's vision is Regional Excellence in the Practice of Project Management through modern, structured management-of-projects concepts that are widely recognized and consistently applied.

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** vision

**Related questions:**

* What is PMI Chennai Chapter (PMICC)?
* When was PMI Chennai Chapter founded?
* What is PMICC's motto or guiding philosophy?

\---

### Q5. What is the mission of PMI Chennai Chapter?

PMICC's mission is to: (1) assist in improving the understanding and ability of experienced and new project management practitioners and customers, (2) assist in improving the maturity and quality of project management practitioners, (3) create awareness in the younger generation at school and college levels, and (4) propagate generally accepted project management approaches and the guide to PMBOK.

**Category:** General / About the Chapter  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** mission

**Related questions:**

* What is PMI Chennai Chapter (PMICC)?
* When was PMI Chennai Chapter founded?
* What is PMICC's motto or guiding philosophy?

\---

### Q6. Where is the PMI Chennai Chapter office located?

PMICC's registered address is: Project Management Institute Chennai Chapter, 715-A, 7th Floor, Spencer Plaza, Suite No.1182, Anna Salai, Chennai - 600 002.

**Category:** General / Contact  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** office, address, location, Spencer Plaza

**Related questions:**

* What is PMI Chennai Chapter (PMICC)?
* When was PMI Chennai Chapter founded?
* What is PMICC's motto or guiding philosophy?

\---

### Q7. What is PMI Chennai Chapter's phone number?

The chapter's listed mobile number on the homepage is +91 87785 66932.

**Category:** General / Contact  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** phone, contact number

**Related questions:**

* What is PMI Chennai Chapter (PMICC)?
* When was PMI Chennai Chapter founded?
* What is PMICC's motto or guiding philosophy?

\---

### Q8. How can I contact PMI Chennai Chapter for volunteering, training, or website queries?

For chapter volunteering queries, email vpvolunteers@pmi-chennai.org. For training program queries, email vpprograms@pmi-chennai.org. For chapter website queries, email vptechnology@pmi-chennai.org.

**Category:** General / Contact  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** contact, email, queries, volunteering contact, training contact, website contact

**Related questions:**

* What is PMI Chennai Chapter (PMICC)?
* When was PMI Chennai Chapter founded?
* What is PMICC's motto or guiding philosophy?

\---

### Q9. What are PMI Chennai Chapter's social media handles?

PMICC is present on Facebook (facebook.com/pmichennai), Twitter/X (@pmichennai), LinkedIn (linkedin.com/school/pmichennai), YouTube, and WhatsApp (a WhatsApp channel link is provided on the site).

**Category:** General / Contact  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** social media, facebook, twitter, linkedin, youtube, whatsapp

**Related questions:**

* What is PMI Chennai Chapter (PMICC)?
* When was PMI Chennai Chapter founded?
* What is PMICC's motto or guiding philosophy?

\---

### Q10. Who is the President of PMI Chennai Chapter?

Vijay Narayanan is the President of PMI Chennai Chapter. He is a senior IT professional with over 24 years of experience, currently a senior manager of Engineering at M\&G Investments. He obtained his PMP certification in 2015 and has been on the chapter board since 2019. Contact: president@pmi-chennai.org, +91 99404 38413.

**Category:** Leadership / Board of Directors  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** president, Vijay Narayanan, board of directors

**Related questions:**

* Who is the Secretary of PMI Chennai Chapter?
* Who are the Vice Presidents on the PMI Chennai Chapter board?
* Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

\---

### Q11. Who is the Secretary of PMI Chennai Chapter?

Vijay Mohan Gandhi is the Executive Vice President and Secretary. He is a technology and delivery leader with 25+ years of experience, currently Domain Head at Ericsson. A PMI member since 2011 and volunteer since 2016. Contact: Secretary@pmi-chennai.org, +91 97910 41947.

**Category:** Leadership / Board of Directors  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** secretary, Vijay Mohan Gandhi

**Related questions:**

* Who is the President of PMI Chennai Chapter?
* Who are the Vice Presidents on the PMI Chennai Chapter board?
* Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

\---

### Q12. Who are the Vice Presidents on the PMI Chennai Chapter board?

The PMICC Board of Directors' Vice Presidents (as listed on the site) include: Haribabuji Harikrishnan (Finance), Sundaram Muthukumarasamy (Governance), Dr. Dinesh Babu Thavamani (Programs), Dr. B. Shyam Sundar (Outreach), Jahnavi Tirumalasetty (Volunteer Development), Swetha Surendran (Women Engagement), Arumugam Mariappan (Technology), Muthukumaran Sowndhararajan (Marketing \& Communications), Vickram S K (Membership), and Krishnakumar Kesavan (Social Impact). Each has a dedicated chapter email address (e.g. vpfinance@pmi-chennai.org, vpgovernance@pmi-chennai.org).

**Category:** Leadership / Board of Directors  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** vice president, VP, board, governance, finance

**Related questions:**

* Who is the President of PMI Chennai Chapter?
* Who is the Secretary of PMI Chennai Chapter?
* Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

\---

### Q13. Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

Yes. The site lists numerous Associate Vice Presidents across portfolios including Women Engagement, Technology, Marketing, Outreach, Outreach Advocacy, Social Impact, Programs, Membership, and Volunteering — for example Latha Vishwanath (AVP Women Engagement), Magesh Rajagopalan (AVP Technology), Mohammed Ejaaz Basheer (AVP Marketing), Ruby S (AVP Outreach), Srivikraman M (AVP Outreach Advocacy), Victor Jacob Damodaram (AVP Social Impact), Vijayakumar VK (AVP Programs), Babu Manivelu and Mahalingam Athmanathan (AVP Membership), Geetha Kathiresan (AVP Social Impact - Coimbatore), Radha Somasundaram (AVP Programs), Sankar Ganesh S (AVP Volunteering), Sridhar Thanikachalam (AVP Programs), and Preethi S (AVP Marketing).

**Category:** Leadership / Chapter Executives  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** AVP, associate vice president, chapter executives

**Related questions:**

* Who is the President of PMI Chennai Chapter?
* Who is the Secretary of PMI Chennai Chapter?
* Who are the Vice Presidents on the PMI Chennai Chapter board?

\---

### Q14. Is PMI Chennai Chapter a registered non-profit?

Yes. PMICC is a registered society under the Tamil Nadu Registration of Societies Act, and operates as a not-for-profit, tax-exempt membership society and a chartered component of PMI (headquartered in Newtown Square, Pennsylvania, USA).

**Category:** Governance / Legal Status  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** non-profit, registered society, tax-exempt, legal status

**Related questions:**

* Has PMI Chennai Chapter won any awards?

\---

### Q15. How do I become a PMI Chennai Chapter member?

To become a PMICC member, you sign up through PMI's official global membership shop page and select the Chennai Chapter. The chapter's website links directly to PMI's chapter-membership page for the Chennai Chapter for this purpose.

**Category:** Membership / How to Join  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** how to join, become a member, membership signup

**Related questions:**

* What is the PMICC 3B Journey for new members?
* When does PMICC run its virtual onboarding session for new members?
* What benefits does PMI membership provide?

\---

### Q16. What is the PMICC 3B Journey for new members?

The 3B Journey is PMICC's 30-60-90 day plan for onboarding new members: 'Belong' (first 30 days — automated welcome email, added to relevant channels), 'Believe' (first 60 days — a virtual onboarding session and an assigned buddy, including introduction to a mentorship track called Project Thunai/Companion based on the member's interest), and 'Become' (first 90 days — encouragement to attend chapter events and take up volunteering opportunities, plus a chance to connect in person quarterly).

**Category:** Membership / Onboarding  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** 3B plan, onboarding, belong believe become, new member

**Related questions:**

* How do I become a PMI Chennai Chapter member?
* When does PMICC run its virtual onboarding session for new members?
* What benefits does PMI membership provide?

\---

### Q17. When does PMICC run its virtual onboarding session for new members?

PMICC runs its virtual onboarding session every second Wednesday evening.

**Category:** Membership / Onboarding  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** onboarding session, schedule, second Wednesday

**Related questions:**

* How do I become a PMI Chennai Chapter member?
* What is the PMICC 3B Journey for new members?
* What benefits does PMI membership provide?

\---

### Q18. What benefits does PMI membership provide?

According to PMICC's membership page, PMI membership benefits include access to the PMBOK standards, PMI Infinity, webinars, eLearning resources, certification discounts, and global job opportunities. PMICC further supplements this with chapter-level initiatives: knowledge sharing, mentoring programs, workshops, conferences, leadership development, community engagement, and networking/mentorship platforms.

**Category:** Membership / Benefits  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** membership benefits, PMBOK, PMI Infinity, eLearning, certification discounts

**Related questions:**

* How do I become a PMI Chennai Chapter member?
* What is the PMICC 3B Journey for new members?
* When does PMICC run its virtual onboarding session for new members?

\---

### Q19. How much does PMI Chennai Chapter membership cost?

The certification-training page (an older, archived listing) mentions chapter membership can be obtained for US $15 as part of a specific training promotion, but this figure is tied to a historical workshop offer, not a current general membership fee schedule. This information is not available on the PMI Chennai website (based on the pages crawled). For the current, authoritative membership fee, use the 'Become a Member' link to PMI's official chapter-membership shop page.

**Category:** Membership / Fees  
**Source:** [Certification \& Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** Medium  
**Tags:** membership fee, cost, price, US $15

**Related questions:**

* How do I become a PMI Chennai Chapter member?
* What is the PMICC 3B Journey for new members?
* When does PMICC run its virtual onboarding session for new members?

\---

### Q20. Where can I find more membership FAQs?

PMICC's membership page links out to PMI's own global membership FAQ page (pmi.org/membership/faq) for further questions.

**Category:** Membership / FAQ  
**Source:** [PMI Chennai Chapter Membership](https://www.pmichennai.org/pmicc-membership/)  
**Confidence:** High  
**Tags:** membership FAQ, PMI FAQ

**Related questions:**

* How do I become a PMI Chennai Chapter member?
* What is the PMICC 3B Journey for new members?
* When does PMICC run its virtual onboarding session for new members?

\---

### Q21. How many members does PMI Chennai Chapter have?

Per the volunteering overview page, PMI Chennai Chapter has over 1,500 members and is growing.

**Category:** Membership / Community Size  
**Source:** [Join Us - Volunteering Overview](https://www.pmichennai.org/join-us-volunteering-overview/)  
**Confidence:** High  
**Tags:** member count, 1500 members, community size

**Related questions:**

* How do I become a PMI Chennai Chapter member?
* What is the PMICC 3B Journey for new members?
* When does PMICC run its virtual onboarding session for new members?

\---

### Q22. Who can volunteer with PMI Chennai Chapter?

The site frames volunteering as open to members of PMICC — both those new to project management and experienced industry veterans. All chapter activities are planned, organized, and led by member volunteers.

**Category:** Volunteering / Overview  
**Source:** [Join Us - Volunteering Overview](https://www.pmichennai.org/join-us-volunteering-overview/)  
**Confidence:** High  
**Tags:** who can volunteer, volunteer eligibility

**Related questions:**

* What are the benefits of volunteering with PMI Chennai Chapter?
* How do I sign up to volunteer at PMI Chennai Chapter?
* How do I sign up to volunteer with PMI Chennai Chapter?

\---

### Q23. What are the benefits of volunteering with PMI Chennai Chapter?

Volunteering lets members develop leadership skills (all chapter activities are planned and led by volunteering members), network with peers across industries, and gain the broader benefits of PMI membership — including members-only services and discounts, complimentary publications, and continuing education opportunities.

**Category:** Volunteering / Benefits  
**Source:** [Join Us - Volunteering Overview](https://www.pmichennai.org/join-us-volunteering-overview/)  
**Confidence:** High  
**Tags:** volunteer benefits, leadership development, networking

**Related questions:**

* Who can volunteer with PMI Chennai Chapter?
* How do I sign up to volunteer at PMI Chennai Chapter?
* How do I sign up to volunteer with PMI Chennai Chapter?

\---

### Q24. How do I sign up to volunteer at PMI Chennai Chapter?

The chapter's navigation menu includes a dedicated 'Enroll as Volunteer' page (Volunteering > Enroll as Volunteer) for signing up. This information is not available on the PMI Chennai website (based on the pages crawled). regarding the exact steps on that specific enrollment page, since it was not part of the pages crawled in this session — check https://www.pmichennai.org/volunteeringopportunities/ directly.

**Category:** Volunteering / How to Join  
**Source:** [Join Us - Volunteering Overview](https://www.pmichennai.org/join-us-volunteering-overview/)  
**Confidence:** Medium  
**Tags:** volunteer signup, enroll, how to volunteer

**Related questions:**

* Who can volunteer with PMI Chennai Chapter?
* What are the benefits of volunteering with PMI Chennai Chapter?
* How do I sign up to volunteer with PMI Chennai Chapter?

\---

### Q25. What certification and training programs does PMI Chennai Chapter offer?

PMICC's Certification \& Training page lists preparatory training for PMI-ACP (via 'ACP \& Beyond'), a PgMP orientation program, and hands-on workshops including Microsoft Project Essentials, JIRA Basics, ProjectLibre Essentials, and Primavera Essentials. The main site navigation also lists separate pages for PMP Certification Training, PMI ACP Certification Training, PgMP Certification Training, an Oracle Primavera Workshop, Design Thinking for Project Managers, a Power BI workshop, a leadership workshop ('Lead Up'), an Introduction to Blockchain Technology, an Artificial Intelligence Workshop, and Essentials of Project Management Using Microsoft Project.

**Category:** Certification / Programs Offered  
**Source:** [Certification \& Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** High  
**Tags:** certification programs, PMP, PMI-ACP, PgMP, workshops, training catalog

**Related questions:**

* Who do I contact to register for PMICC training or certification programs?
* How much did the PgMP one-day training program cost?
* How do I pay for a PMICC training program by bank transfer?

\---

### Q26. Who do I contact to register for PMICC training or certification programs?

Registration and certification-training queries go to vpcertification@pmi-chennai.org (also referenced historically as Training@pmi-chennai.org for payment confirmations).

**Category:** Certification / Who To Contact  
**Source:** [Certification \& Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** High  
**Tags:** registration, training contact, vpcertification

**Related questions:**

* What certification and training programs does PMI Chennai Chapter offer?
* How much did the PgMP one-day training program cost?
* How do I pay for a PMICC training program by bank transfer?

\---

### Q27. How much did the PgMP one-day training program cost?

In an archived listing on the site, the 1-Day PgMP Training Program was priced at Rs. 4,000 + 18% GST for PMI Chennai members and Rs. 6,000 + 18% GST for non-members. This is historical/example pricing from a past batch, not a standing current fee — always confirm current pricing directly with vpcertification@pmi-chennai.org.

**Category:** Certification / Fees (Historical Example)  
**Source:** [Certification \& Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** Medium  
**Tags:** PgMP fee, training cost, pricing example

**Related questions:**

* What certification and training programs does PMI Chennai Chapter offer?
* Who do I contact to register for PMICC training or certification programs?
* How do I pay for a PMICC training program by bank transfer?

\---

### Q28. How do I pay for a PMICC training program by bank transfer?

An archived workshop listing gives these bank transfer details: Account Name: PMI Chennai Chapter; Bank: Kotak Mahindra Bank; Branch: Adyar; Account type: Current account; Account No: 5711125967; IFSC Code: KKBK0000463. After transferring, participants were asked to email a screenshot of the transaction to Training@pmi-chennai.org / vpcertification@pmi-chennai.org for reconciliation. Confirm these details are still current before making a payment, since this was found on an older archived page.

**Category:** Certification / Payment  
**Source:** [Certification \& Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** Medium  
**Tags:** bank transfer, payment, IFSC, account number

**Related questions:**

* What certification and training programs does PMI Chennai Chapter offer?
* Who do I contact to register for PMICC training or certification programs?
* How much did the PgMP one-day training program cost?

\---

### Q29. Do PMICC workshops offer PDUs?

Yes, several archived workshop listings (e.g. Microsoft Project 2016 Essentials, JIRA, Project Libre Essentials, Primavera Essentials) awarded 6.0 PDUs each. PDU amounts vary by workshop; check the specific event page for current figures.

**Category:** Certification / PDUs  
**Source:** [Certification \& Training](https://www.pmichennai.org/certification-training/)  
**Confidence:** High  
**Tags:** PDU, professional development units, 6.0 PDUs

**Related questions:**

* What certification and training programs does PMI Chennai Chapter offer?
* Who do I contact to register for PMICC training or certification programs?
* How much did the PgMP one-day training program cost?

\---

### Q30. What sections does the PMI Chennai Chapter website have?

The main navigation includes: Home; About Us (About Chapter, Chapter Executives, Additional Chapter Executives, Awards and Accolades, PMI Chennai Chapter Membership); Certification \& Training (PMP, PMI-ACP, PgMP, Oracle Primavera Workshop, Design Thinking, Power BI, Leadership 'Lead Up', Blockchain, AI Workshop, MS Project Essentials); Outreach (Overview, Corporate Outreach, Academic Outreach, Chapter Students Club, Chapter Ambassador Program); Volunteering (Overview, Enroll as Volunteer, Volunteer Recognitions, Volunteer Voice); and a 'More' menu (Chapter Events, Chapter Highlights/News, Events Calendar, Events Gallery, Career++, Newsletter, PMI AI Assistant, Coimbatore Branch, Social Impact, Women Empowerment).

**Category:** Website Navigation / Site Map  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** site map, navigation, menu structure

**Related questions:**

* Does PMI Chennai Chapter have a branch outside Chennai?

\---

### Q31. Does PMI Chennai Chapter have a branch outside Chennai?

Yes, the navigation lists a 'PMI Chennai Chapter - Coimbatore Branch' page, indicating the chapter also has activity/presence in Coimbatore (referred to informally on the site as 'Kovai').

**Category:** Website Navigation / Regional Branch  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** Coimbatore, Kovai, branch, regional presence

**Related questions:**

* What sections does the PMI Chennai Chapter website have?

\---

### Q32. How long is the PMP certification training program at PMICC?

PMICC's PMP Certification Training runs 100 hours total with 180 days of support and mentoring, broken into 35 hours of training (virtual or in-person), 35 hours of preparation (8 hours weekly), and 30 hours of 1-on-1 mock exam mentoring.

**Category:** Certification / PMP  
**Source:** [PMP Certification Training](https://www.pmichennai.org/pmp/)  
**Confidence:** High  
**Tags:** PMP, duration, training hours, mentoring

**Related questions:**

* What certification and training programs does PMI Chennai Chapter offer?
* Who do I contact to register for PMICC training or certification programs?
* How much did the PgMP one-day training program cost?

\---

### Q33. Who is eligible for PMICC's PMP training?

Any individual who is eligible per PMI's official PMP requirements and is aspiring to earn the PMP certification can attend. Eligibility should be checked directly on PMI's PMP certification page.

**Category:** Certification / PMP  
**Source:** [PMP Certification Training](https://www.pmichennai.org/pmp/)  
**Confidence:** High  
**Tags:** PMP eligibility, who can attend

**Related questions:**

* What certification and training programs does PMI Chennai Chapter offer?
* Who do I contact to register for PMICC training or certification programs?
* How much did the PgMP one-day training program cost?

\---

### Q34. How much does the PMI-ACP training cost at PMICC?

In an archived program listing, PMI-ACP training cost Rs. 10,620 for PMI Chapter Members and Rs. 11,800 for Non-Members, both including 18% GST. Confirm current pricing directly with the chapter, as this was tied to a specific past batch (17-24 August 2024, online).

**Category:** Certification / PMI-ACP  
**Source:** [PMI ACP Certification Training](https://www.pmichennai.org/acp/)  
**Confidence:** Medium  
**Tags:** PMI-ACP fee, agile certification cost, member price

**Related questions:**

* What certification and training programs does PMI Chennai Chapter offer?
* Who do I contact to register for PMICC training or certification programs?
* How much did the PgMP one-day training program cost?

\---

### Q35. Who delivers PMICC's PgMP certification training?

PMICC partners with INFOCAREER, an official PMI Authorized Training Partner in Chennai, to deliver PgMP training. It includes 180 days of 1-on-1 mentoring (the PgMP-Assure program), an e-learning companion portal, mock exams, and 24x7 email/phone/WhatsApp support on working days.

**Category:** Certification / PgMP  
**Source:** [PgMP Certification Training](https://www.pmichennai.org/pgmp-certification-training/)  
**Confidence:** High  
**Tags:** PgMP, INFOCAREER, program management certification, mentoring

**Related questions:**

* What certification and training programs does PMI Chennai Chapter offer?
* Who do I contact to register for PMICC training or certification programs?
* How much did the PgMP one-day training program cost?

\---

### Q36. What is PMICC's Outreach Portfolio?

The PMI Chennai Chapter Outreach Portfolio connects industry, academia, and community to cultivate project leadership, aiming to help close the global talent gap driving demand for 25 million project managers by 2030. It spans Academic Outreach and Corporate Outreach.

**Category:** Outreach / Overview  
**Source:** [Outreach – An Overview](https://www.pmichennai.org/outreach/)  
**Confidence:** High  
**Tags:** outreach, 25 million project managers, talent gap

**Related questions:**

* Who leads PMICC's Outreach portfolio?
* How can my company partner with PMI Chennai Chapter?
* Does PMI offer scholarships for students through PMI Chennai Chapter?

\---

### Q37. Who leads PMICC's Outreach portfolio?

Dr. B. Shyam Sundar is the Vice President of Outreach (vpoutreach@pmi-chennai.org, +91 94455 42436). Srivikraman M serves as Associate Vice President of Outreach Advocacy (avpadvocacy@pmi-chennai.com, 8667302828).

**Category:** Outreach / Overview  
**Source:** [Outreach – An Overview](https://www.pmichennai.org/outreach/)  
**Confidence:** High  
**Tags:** outreach leadership, VP outreach, Shyam Sundar

**Related questions:**

* What is PMICC's Outreach Portfolio?
* How can my company partner with PMI Chennai Chapter?
* Does PMI offer scholarships for students through PMI Chennai Chapter?

\---

### Q38. How can my company partner with PMI Chennai Chapter?

PMICC's Corporate Outreach offers customized corporate training (PMP, PMI-ACP, CAPM), networking forums, leadership development sessions, joint events with academia, and volunteer opportunities for employees — aligning with corporate CSR goals. Companies can reach out via the chapter's outreach contact to start a partnership.

**Category:** Outreach / Corporate  
**Source:** [Corporate Outreach](https://www.pmichennai.org/corporate-outreach/)  
**Confidence:** High  
**Tags:** corporate partnership, corporate training, CSR, how to partner

**Related questions:**

* What is PMICC's Outreach Portfolio?
* Who leads PMICC's Outreach portfolio?
* Does PMI offer scholarships for students through PMI Chennai Chapter?

\---

### Q39. Does PMI offer scholarships for students through PMI Chennai Chapter?

Yes — via PMI's global academic programs, which PMICC's Academic Outreach connects students to. PMI offers academic scholarships ranging from US$1,000 to US$7,500 for students studying project management and related disciplines, with applications typically opening in March each year.

**Category:** Outreach / Academic  
**Source:** [Academic Outreach](https://www.pmichennai.org/academic-outreach/)  
**Confidence:** High  
**Tags:** scholarships, PMI scholarships, students, US$1000-7500

**Related questions:**

* What is PMICC's Outreach Portfolio?
* Who leads PMICC's Outreach portfolio?
* How can my company partner with PMI Chennai Chapter?

\---

### Q40. What is Group Student Membership (GSM)?

Group Student Membership is a PMI program that lets institutions enroll students as PMI members in bulk, billed to the institution with bulk discounts and one complimentary faculty membership included. Benefits include certification/eLearning discounts, a digital PMBOK Guide and Agile Practice Guide, and networking/volunteering access through the local PMI chapter. More info is available at PMI.org/GSM.

**Category:** Outreach / Academic  
**Source:** [Academic Outreach](https://www.pmichennai.org/academic-outreach/)  
**Confidence:** High  
**Tags:** GSM, group student membership, institution membership

**Related questions:**

* What is PMICC's Outreach Portfolio?
* Who leads PMICC's Outreach portfolio?
* How can my company partner with PMI Chennai Chapter?

\---

### Q41. What is the PMI Global Accreditation Center (GAC)?

The GAC is PMI's specialized accrediting body for project management degree programs at the bachelor's, postgraduate, and doctorate levels. Over 170 higher-education project management programs worldwide have achieved GAC accreditation.

**Category:** Outreach / Academic  
**Source:** [Academic Outreach](https://www.pmichennai.org/academic-outreach/)  
**Confidence:** High  
**Tags:** GAC, accreditation, PM degree programs

**Related questions:**

* What is PMICC's Outreach Portfolio?
* Who leads PMICC's Outreach portfolio?
* How can my company partner with PMI Chennai Chapter?

\---

### Q42. Which colleges has PMI Chennai Chapter partnered with?

Per the Academic Outreach page's event highlights, PMICC has active partnerships/MoUs with VIT Business School, Kumaraguru College of Technology (KCT) Coimbatore, Jansons Institutions, Sri Ramakrishna Engineering College (Coimbatore), and RICS-Crescent CoEBE, among others.

**Category:** Outreach / Academic  
**Source:** [Academic Outreach](https://www.pmichennai.org/academic-outreach/)  
**Confidence:** High  
**Tags:** college partnerships, MoU, VIT, KCT, Jansons, RICS Crescent

**Related questions:**

* What is PMICC's Outreach Portfolio?
* Who leads PMICC's Outreach portfolio?
* How can my company partner with PMI Chennai Chapter?

\---

### Q43. What is a PMI Chapter Student Club and how do I join one?

A PMI Chapter Student Club is a student-led organization supported by PMICC that provides hands-on PM experience, leadership development, networking, career opportunities, and access to jobs/internships. PMICC has launched student clubs at institutions including Amrita School of Business, KCT Business School, and Jansons School of Business — check with your institution or PMICC's outreach team about starting or joining one.

**Category:** Outreach / Student Club  
**Source:** [Chapter Students Club](https://www.pmichennai.org/chapter-students-club/)  
**Confidence:** High  
**Tags:** student club, how to join, campus club

**Related questions:**

* What is PMICC's Outreach Portfolio?
* Who leads PMICC's Outreach portfolio?
* How can my company partner with PMI Chennai Chapter?

\---

### Q44. What is the PMI Chennai Chapter Ambassador Program?

The Chapter Ambassador Program (CAP) is a flagship Corporate Outreach initiative connecting PMICC with local organizations across Chennai and Tamil Nadu. Ambassadors act as their organization's voice within PMICC, earn PDUs for participating in Ambassador meetings, and help grow PM awareness and PMI membership within their companies.

**Category:** Outreach / Chapter Ambassador  
**Source:** [Chapter Ambassador Program](https://www.pmichennai.org/chapter-ambassador-program/)  
**Confidence:** High  
**Tags:** chapter ambassador, CAP, corporate liaison

**Related questions:**

* What is PMICC's Outreach Portfolio?
* Who leads PMICC's Outreach portfolio?
* How can my company partner with PMI Chennai Chapter?

\---

### Q45. Who is eligible to become a PMI Chennai Chapter Ambassador, and how do I apply?

You must be a member of both PMI and the PMI Chennai Chapter. Interested applicants complete the online Chapter Ambassador Application (a Google Form linked from the Chapter Ambassador Program page) or contact vpoutreach@pmi-chennai.org with questions.

**Category:** Outreach / Chapter Ambassador  
**Source:** [Chapter Ambassador Program](https://www.pmichennai.org/chapter-ambassador-program/)  
**Confidence:** High  
**Tags:** ambassador eligibility, how to apply, application form

**Related questions:**

* What is PMICC's Outreach Portfolio?
* Who leads PMICC's Outreach portfolio?
* How can my company partner with PMI Chennai Chapter?

\---

### Q46. How do I sign up to volunteer with PMI Chennai Chapter?

Existing PMI members interested in volunteering should watch the 'Enroll as Volunteer' page for new opportunities and reach out to the VP of Volunteer Development at vpvolunteers@pmi-chennai.org. The page also provides a QR code for quick volunteer signup.

**Category:** Volunteering / Enrollment  
**Source:** [Volunteering Opportunities (Enroll as Volunteer)](https://www.pmichennai.org/volunteeringopportunities/)  
**Confidence:** High  
**Tags:** volunteer signup, enroll as volunteer, QR code

**Related questions:**

* Who can volunteer with PMI Chennai Chapter?
* What are the benefits of volunteering with PMI Chennai Chapter?
* How do I sign up to volunteer at PMI Chennai Chapter?

\---

### Q47. What events does PMI Chennai Chapter have coming up?

As of the last crawl (site content dated July 2026), upcoming events listed include 'PMI Chennai Chapter First Workshop at Kovai - Fundamentals of Artificial Intelligence' (Saturday, 1 August 2026, in Coimbatore) and a paid workshop 'A Handshake Between Design Thinking \& AI' (25 July 2026, at Nagarjuna Hall, IIT Madras Research Park). Check the Chapter Events and Events Calendar pages directly for the latest listings, since this changes frequently.

**Category:** Events / Upcoming Events  
**Source:** [Chapter Events](https://www.pmichennai.org/chapter-events/)  
**Confidence:** Medium  
**Tags:** upcoming events, event calendar, AI workshop, design thinking workshop

**Related questions:**

* What is Kovai Sangamam?

\---

### Q48. What is Kovai Sangamam?

Kovai Sangamam is PMICC's flagship conference/summit held in Coimbatore ('Kovai'). Kovai Sangamam 2026 was notably the occasion at which the PMI Chennai Chapter - Coimbatore Branch was formally inaugurated, with 300+ delegates and 10+ speakers in attendance.

**Category:** Events / Flagship Event  
**Source:** [PMI Chennai Chapter Comes Home to Coimbatore](https://www.pmichennai.org/pmicc-coimbatore-branch/)  
**Confidence:** High  
**Tags:** Kovai Sangamam, flagship conference, Coimbatore event

**Related questions:**

* What events does PMI Chennai Chapter have coming up?

\---

### Q49. When and how was the PMI Chennai Chapter Coimbatore Branch launched?

The PMI Chennai Chapter - Coimbatore Branch was inaugurated at Kovai Sangamam 2026, with Thiru C. K. Kumaravel (CMD, Naturals) as Chief Guest and Mr. Rajendran Dandapani (Director, Zoho Corporation) inaugurating the branch. Chapter President Vijay Narayanan, Secretary Vijay Mohan Gandhi, and several VPs attended, along with 300+ delegates and 10+ speakers.

**Category:** Regional Presence / Coimbatore Branch  
**Source:** [PMI Chennai Chapter Comes Home to Coimbatore](https://www.pmichennai.org/pmicc-coimbatore-branch/)  
**Confidence:** High  
**Tags:** Coimbatore branch launch, Kovai Sangamam 2026, branch inauguration



\---

### Q50. Has PMI Chennai Chapter won any awards?

Yes. PMI Chennai Chapter was awarded the PMI Chapter of the Year Award 2025, a global recognition announced at the 2025 PMI Global Awards during the PMI Global Summit 2025 in Phoenix, Arizona, USA. PMICC was selected as the winner among regional finalists from Africa, Asia Pacific, Europe, Latin America, and North America.

**Category:** Governance / Awards  
**Source:** [Social Impact](https://www.pmichennai.org/socialimpact/)  
**Confidence:** High  
**Tags:** Chapter of the Year, award 2025, PMI Global Summit, Phoenix Arizona

**Related questions:**

* Is PMI Chennai Chapter a registered non-profit?

\---

### Q51. What social impact initiatives does PMI Chennai Chapter run?

Key initiatives include Project Puthri (life-skills sessions delivered to 10,000+ girls across 100+ Tamil Nadu schools since 2018), Project Nibuni (PM sessions in colleges in partnership with Avtar Trust, from January 2026), environmental drives (including planting 1,500 trees), and Thittamidu Vetrithodu, a Tamil-language project management book distributed to government schools. These align with UN Sustainable Development Goals.

**Category:** Social Impact / Overview  
**Source:** [Social Impact](https://www.pmichennai.org/socialimpact/)  
**Confidence:** High  
**Tags:** social impact, Project Puthri, Project Nibuni, Thittamidu Vetrithodu, UN SDGs

**Related questions:**

* How many members does PMI Chennai Chapter have now?

\---

### Q52. How many members does PMI Chennai Chapter have now?

Per the Social Impact page, PMICC now has 3,200+ members (this is a more recent figure than the 1,500+ mentioned on the Volunteering Overview page, reflecting chapter growth over time).

**Category:** Social Impact / Member Count  
**Source:** [Social Impact](https://www.pmichennai.org/socialimpact/)  
**Confidence:** High  
**Tags:** member count, 3200 members, chapter growth

**Related questions:**

* What social impact initiatives does PMI Chennai Chapter run?

\---

### Q53. Does PMI Chennai Chapter have a program for women members?

Yes — PMICHENNAI-WEC (Women Empowerment Committee), a dedicated group with 150+ women members across industries. It runs four initiatives: W-Greet n Meet (informal networking), W-Entrepreneur Connect (for women entrepreneurs), W-Pause and Restart (career-break support and return-to-work opportunities), and W-Groom (mentoring for female students). Contact vpwomenempowerment@pmi-chennai.org for more information.

**Category:** Community / Women Empowerment  
**Source:** [Women Empowerment](https://www.pmichennai.org/women-empowerment/)  
**Confidence:** High  
**Tags:** women empowerment, WEC, W-Pause and Restart, women members



\---

### Q54. Does PMI Chennai Chapter provide career guidance or job resources?

Yes — the Career++ page offers a project management career FAQ (covering topics like transitioning to program management, AI's impact on PM careers, and career changes), resume writing guidelines with a downloadable template, and a link to PMI's global job board (pmjobs.pmi.org).

**Category:** Career / Resources  
**Source:** [Career++](https://www.pmichennai.org/career/)  
**Confidence:** High  
**Tags:** career resources, resume template, job board, career FAQ

**Related questions:**

* What resume format does PMI Chennai Chapter recommend?

\---

### Q55. What resume format does PMI Chennai Chapter recommend?

The Career++ page recommends: keep resumes to two pages, be concise and specific (avoid generic terms like 'team player'), avoid personal details (marital status, religion, date of birth, salary), and structure it with Basic Details, Summary, Experience (most recent first), Academics, Certifications, and Professional Memberships sections. A downloadable sample resume template is provided on the page.

**Category:** Career / Resume  
**Source:** [Career++](https://www.pmichennai.org/career/)  
**Confidence:** High  
**Tags:** resume guidelines, resume format, resume template

**Related questions:**

* Does PMI Chennai Chapter provide career guidance or job resources?

\---





=========================================================

PMI CHENNAI CHAPTER LEADERSHIP (2025-2026)

=========================================================



=== BOARD OF DIRECTORS ===



\- President: Vijay Narayanan

&#x20; Email: president@pmi-chennai.org

&#x20; Description: Provides strategic leadership for the chapter, defines vision, governance, partnerships, and overall organizational growth.



\- Vice President of Technology: Arumugam Mariappan

&#x20; Email: vptechnology@pmi-chennai.org

&#x20; Description: Leads chapter technology strategy, digital transformation, website, AI initiatives, automation, cybersecurity, infrastructure, and technology innovation.



\- Associate Vice President (AVP) of Technology: Magesh Rajagopalan

&#x20; Description: Supports technology operations, website enhancements, digital platforms, automation initiatives, and technical project delivery.



\- Vice President of Social Impact: Krishnakumar Kesavan

&#x20; Email: vpsocialimpact@pmi-chennai.org

&#x20; Description: Leads community outreach, CSR initiatives, NGO partnerships, and social responsibility programs.



\- Associate Vice President (AVP) of Social Impact: Victor Jacob Damodaram

&#x20; Description: Supports execution of social impact initiatives, volunteer engagement, and community partnerships.



\- Vice President of Finance: Haribabuji Harikrishnan

&#x20; Email: vpfinance@pmi-chennai.org

&#x20; Description: Oversees financial planning, budgeting, accounting, statutory compliance, and financial governance.



\- Vice President of Membership: Sundaram M

&#x20; Email: vpmembership@pmi-chennai.org

&#x20; Description: Drives membership growth, retention, engagement, onboarding, and member experience.



\- Vice President of Programs: Vijay Mohan Gandhi

&#x20; Email: vpprograms@pmi-chennai.org

&#x20; Description: Plans and delivers knowledge sharing sessions, workshops, webinars, and professional development programs.



\- Vice President of Volunteers: Jahnavi Thirumalasetty

&#x20; Email: vpvolunteers@pmi-chennai.org

&#x20; Description: Recruits, develops, engages, and recognizes chapter volunteers.



\- Vice President of Marketing: Dr. B. Shyam Sundar

&#x20; Email: vpmarketing@pmi-chennai.org

&#x20; Description: Leads branding, communications, social media, digital marketing, and promotional campaigns.



\- Vice President of Women Engagement: Swetha Surendran

&#x20; Email: vpwomenengagement@pmi-chennai.org

&#x20; Description: Promotes leadership development, networking, and engagement opportunities for women professionals.



\- Vice President of Academia: MuthuKumaran Sowndhararajan

&#x20; Email: vpacademia@pmi-chennai.org

&#x20; Description: Builds partnerships with educational institutions and expands student engagement initiatives.



\- Vice President of Governance: Prasanna Sampathkumar

&#x20; Email: vpgovernance@pmi-chennai.org

&#x20; Description: Ensures governance compliance, policy adherence, elections, documentation, and chapter operational excellence.



=========================================================

EXTENDED BOARD

=========================================================



\- Associate Vice President (AVP) of Technology: Magesh Rajagopalan

&#x20; Description: Supports technology portfolio and digital initiatives.



\- Associate Vice President (AVP) of Programs: Babu Manivelu

&#x20; Description: Assists in planning and executing professional development programs and workshops.



\- Associate Vice President (AVP) of Membership: Vijayakumar VK

&#x20; Description: Supports membership onboarding, engagement, and member services.



\- Associate Vice President (AVP) of Marketing: Preethi S

&#x20; Description: Supports marketing campaigns, branding, digital communications, and promotional activities.



\- Associate Vice President (AVP) of Volunteering: Sankar Ganesh S

&#x20; Description: Supports volunteer recruitment, coordination, engagement, and recognition.



\- Associate Vice President (AVP) of Social Impact: Victor Jacob Damodaram

&#x20; Description: Supports CSR programs, NGO collaborations, and community outreach initiatives.



=========================================================

CHAPTER OFFICE

=========================================================



Project Management Institute Chennai Chapter

715-A, 7th Floor,

Spencer Plaza,

Suite No.1182,

Anna Salai,

Chennai – 600002



General Contact:

president@pmi-chennai.org


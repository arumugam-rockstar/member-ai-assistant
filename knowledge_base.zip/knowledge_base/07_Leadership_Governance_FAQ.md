# 07 Leadership Governance FAQ

### Q1. Who is the President of PMI Chennai Chapter?

Vijay Narayanan is the President of PMI Chennai Chapter. He is a senior IT professional with over 24 years of experience, currently a senior manager of Engineering at M\&G Investments. He obtained his PMP certification in 2015 and has been on the chapter board since 2019. Contact: president@pmi-chennai.org, +91 99404 38413.

**Category:** Leadership / Board of Directors  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** president, Vijay Narayanan, board of directors

**Related questions:**

* Who is the Secretary of PMI Chennai Chapter?
* Who are the Vice Presidents on the PMI Chennai Chapter board?
* Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

\---

### Q2. Who is the Secretary of PMI Chennai Chapter?

Vijay Mohan Gandhi is the Executive Vice President and Secretary. He is a technology and delivery leader with 25+ years of experience, currently Domain Head at Ericsson. A PMI member since 2011 and volunteer since 2016. Contact: Secretary@pmi-chennai.org, +91 97910 41947.

**Category:** Leadership / Board of Directors  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** secretary, Vijay Mohan Gandhi

**Related questions:**

* Who is the President of PMI Chennai Chapter?
* Who are the Vice Presidents on the PMI Chennai Chapter board?
* Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

\---

### Q3. Who are the Vice Presidents on the PMI Chennai Chapter board?

The PMICC Board of Directors' Vice Presidents (as listed on the site) include: Haribabuji Harikrishnan (Finance), Sundaram Muthukumarasamy (VP Governance), Dr. Dinesh Babu Thavamani (VP Programs), Dr. B. Shyam Sundar (VP Outreach), Jahnavi Tirumalasetty (VP Volunteer Development), Swetha Surendran (VP Women Engagement), Arumugam Mariappan (VP Technology), Muthukumaran Sowndhararajan (VP Marketing \& Communications), Vickram S K (VP Membership), and Krishnakumar Kesavan (VP Social Impact). Each has a dedicated chapter email address (e.g. vpfinance@pmi-chennai.org, vpgovernance@pmi-chennai.org).

**Category:** Leadership / Board of Directors  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** vice president, VP, board, governance, finance

**Related questions:**

* Who is the President of PMI Chennai Chapter?
* Who is the Secretary of PMI Chennai Chapter?
* Are there Vice Presidents (AVPs) at PMI Chennai Chapter?

\---

### Q4. Are there Associate Vice Presidents (AVPs) at PMI Chennai Chapter?

Yes. The site lists numerous Associate Vice Presidents across portfolios including Women Engagement, Technology, Marketing, Outreach, Outreach Advocacy, Social Impact, Programs, Membership, and Volunteering — for example Latha Vishwanath (AVP Women Engagement), Magesh Rajagopalan (AVP Technology), Mohammed Ejaaz Basheer (AVP Marketing), Ruby S (AVP Outreach), Srivikraman M (AVP Outreach Advocacy), Victor Jacob Damodaram (AVP Social Impact), Vijayakumar VK (AVP Programs), Babu Manivelu and Mahalingam Athmanathan (AVP Membership), Geetha Kathiresan (AVP Social Impact - Coimbatore), Radha Somasundaram (AVP Programs), Sankar Ganesh S (AVP Volunteering), Sridhar Thanikachalam (AVP Programs), and Preethi S (AVP Marketing).

**Category:** Leadership / Chapter Executives  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** AVP, associate vice president, chapter executives

**Related questions:**

* Who is the President of PMI Chennai Chapter?
* Who is the Secretary of PMI Chennai Chapter?
* Who are the Associate Vice Presidents on the PMI Chennai Chapter Extended board?

\---

### Q5. Is PMI Chennai Chapter a registered non-profit?

Yes. PMICC is a registered society under the Tamil Nadu Registration of Societies Act, and operates as a not-for-profit, tax-exempt membership society and a chartered component of PMI (headquartered in Newtown Square, Pennsylvania, USA).

**Category:** Governance / Legal Status  
**Source:** [Home](https://www.pmichennai.org/)  
**Confidence:** High  
**Tags:** non-profit, registered society, tax-exempt, legal status

**Related questions:**

* Has PMI Chennai Chapter won any awards?

\---

### Q6. Has PMI Chennai Chapter won any awards?

Yes. PMI Chennai Chapter was awarded the PMI Chapter of the Year Award 2025, a global recognition announced at the 2025 PMI Global Awards during the PMI Global Summit 2025 in Phoenix, Arizona, USA. PMICC was selected as the winner among regional finalists from Africa, Asia Pacific, Europe, Latin America, and North America.

**Category:** Governance / Awards  
**Source:** [Social Impact](https://www.pmichennai.org/socialimpact/)  
**Confidence:** High  
**Tags:** Chapter of the Year, award 2025, PMI Global Summit, Phoenix Arizona

**Related questions:**

* Is PMI Chennai Chapter a registered non-profit?

\---



## Leadership Reference (2025-2026)

* &#x20;=========================================================
* PMI CHENNAI CHAPTER LEADERSHIP (2025-2026)
* =========================================================
* 
* === BOARD OF DIRECTORS ===
* 
* \- President: Vijay Narayanan
* &#x20; Email: president@pmi-chennai.org
* &#x20; Description: Provides strategic leadership for the chapter, defines vision, governance, partnerships, and overall organizational growth.
* 
* \- Vice President of Technology: Arumugam Mariappan
* &#x20; Email: vptechnology@pmi-chennai.org
* &#x20; Description: Leads chapter technology strategy, digital transformation, website, AI initiatives, automation, cybersecurity, infrastructure, and technology innovation.
* 
* \- Associate Vice President (AVP) of Technology: Magesh Rajagopalan
* &#x20; Description: Supports technology operations, website enhancements, digital platforms, automation initiatives, and technical project delivery.
* 
* \- Vice President of Social Impact: Krishnakumar Kesavan
* &#x20; Email: vpsocialimpact@pmi-chennai.org
* &#x20; Description: Leads community outreach, CSR initiatives, NGO partnerships, and social responsibility programs.
* 
* \- Associate Vice President (AVP) of Social Impact: Victor Jacob Damodaram
* &#x20; Description: Supports execution of social impact initiatives, volunteer engagement, and community partnerships.
* 
* \- Vice President of Finance: Haribabuji Harikrishnan
* &#x20; Email: vpfinance@pmi-chennai.org
* &#x20; Description: Oversees financial planning, budgeting, accounting, statutory compliance, and financial governance.
* 
* \- Vice President of Membership: Sundaram M
* &#x20; Email: vpmembership@pmi-chennai.org
* &#x20; Description: Drives membership growth, retention, engagement, onboarding, and member experience.
* 
* \- Vice President of Programs: Vijay Mohan Gandhi
* &#x20; Email: vpprograms@pmi-chennai.org
* &#x20; Description: Plans and delivers knowledge sharing sessions, workshops, webinars, and professional development programs.
* 
* \- Vice President of Volunteers: Jahnavi Thirumalasetty
* &#x20; Email: vpvolunteers@pmi-chennai.org
* &#x20; Description: Recruits, develops, engages, and recognizes chapter volunteers.
* 
* \- Vice President of Marketing: Dr. B. Shyam Sundar
* &#x20; Email: vpmarketing@pmi-chennai.org
* &#x20; Description: Leads branding, communications, social media, digital marketing, and promotional campaigns.
* 
* \- Vice President of Women Engagement: Swetha Surendran
* &#x20; Email: vpwomenengagement@pmi-chennai.org
* &#x20; Description: Promotes leadership development, networking, and engagement opportunities for women professionals.
* 
* \- Vice President of Academia: MuthuKumaran Sowndhararajan
* &#x20; Email: vpacademia@pmi-chennai.org
* &#x20; Description: Builds partnerships with educational institutions and expands student engagement initiatives.
* 
* \- Vice President of Governance: Prasanna Sampathkumar
* &#x20; Email: vpgovernance@pmi-chennai.org
* &#x20; Description: Ensures governance compliance, policy adherence, elections, documentation, and chapter operational excellence.
* 
* =========================================================
* EXTENDED BOARD
* =========================================================
* 
* \- Associate Vice President (AVP) of Technology: Magesh Rajagopalan
* &#x20; Description: Supports technology portfolio and digital initiatives.
* 
* \- Associate Vice President (AVP) of Programs: Babu Manivelu
* &#x20; Description: Assists in planning and executing professional development programs and workshops.
* 
* \- Associate Vice President (AVP) of Membership: Vijayakumar VK
* &#x20; Description: Supports membership onboarding, engagement, and member services.
* 
* \- Associate Vice President (AVP) of Marketing: Preethi S
* &#x20; Description: Supports marketing campaigns, branding, digital communications, and promotional activities.
* 
* \- Associate Vice President (AVP) of Volunteering: Sankar Ganesh S
* &#x20; Description: Supports volunteer recruitment, coordination, engagement, and recognition.
* 
* \- Associate Vice President (AVP) of Social Impact: Victor Jacob Damodaram
* &#x20; Description: Supports CSR programs, NGO collaborations, and community outreach initiatives.
* 
* =========================================================
* CHAPTER OFFICE
* =========================================================
* 
* Project Management Institute Chennai Chapter
* 715-A, 7th Floor,
* Spencer Plaza,
* Suite No.1182,
* Anna Salai,
* Chennai – 600002
* 
* General Contact:
* president@pmi-chennai.org


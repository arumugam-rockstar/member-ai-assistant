# 10 Outreach FAQ

### Q1. What is PMICC's Outreach Portfolio?

The PMI Chennai Chapter Outreach Portfolio connects industry, academia, and community to cultivate project leadership, aiming to help close the global talent gap driving demand for 25 million project managers by 2030. It spans Academic Outreach and Corporate Outreach.

**Category:** Outreach / Overview  
**Source:** [Outreach – An Overview](https://www.pmichennai.org/outreach/)  
**Confidence:** High  
**Tags:** outreach, 25 million project managers, talent gap

**Related questions:**
- Who leads PMICC's Outreach portfolio?
- How can my company partner with PMI Chennai Chapter?
- Does PMI offer scholarships for students through PMI Chennai Chapter?

---

### Q2. Who leads PMICC's Outreach portfolio?

Dr. B. Shyam Sundar is the Vice President of Outreach (vpoutreach@pmi-chennai.org, +91 94455 42436). Srivikraman M serves as Associate Vice President of Outreach Advocacy (avpadvocacy@pmi-chennai.com, 8667302828).

**Category:** Outreach / Overview  
**Source:** [Outreach – An Overview](https://www.pmichennai.org/outreach/)  
**Confidence:** High  
**Tags:** outreach leadership, VP outreach, Shyam Sundar

**Related questions:**
- What is PMICC's Outreach Portfolio?
- How can my company partner with PMI Chennai Chapter?
- Does PMI offer scholarships for students through PMI Chennai Chapter?

---

### Q3. How can my company partner with PMI Chennai Chapter?

PMICC's Corporate Outreach offers customized corporate training (PMP, PMI-ACP, CAPM), networking forums, leadership development sessions, joint events with academia, and volunteer opportunities for employees — aligning with corporate CSR goals. Companies can reach out via the chapter's outreach contact to start a partnership.

**Category:** Outreach / Corporate  
**Source:** [Corporate Outreach](https://www.pmichennai.org/corporate-outreach/)  
**Confidence:** High  
**Tags:** corporate partnership, corporate training, CSR, how to partner

**Related questions:**
- What is PMICC's Outreach Portfolio?
- Who leads PMICC's Outreach portfolio?
- Does PMI offer scholarships for students through PMI Chennai Chapter?

---

### Q4. Does PMI offer scholarships for students through PMI Chennai Chapter?

Yes — via PMI's global academic programs, which PMICC's Academic Outreach connects students to. PMI offers academic scholarships ranging from US$1,000 to US$7,500 for students studying project management and related disciplines, with applications typically opening in March each year.

**Category:** Outreach / Academic  
**Source:** [Academic Outreach](https://www.pmichennai.org/academic-outreach/)  
**Confidence:** High  
**Tags:** scholarships, PMI scholarships, students, US$1000-7500

**Related questions:**
- What is PMICC's Outreach Portfolio?
- Who leads PMICC's Outreach portfolio?
- How can my company partner with PMI Chennai Chapter?

---

### Q5. What is Group Student Membership (GSM)?

Group Student Membership is a PMI program that lets institutions enroll students as PMI members in bulk, billed to the institution with bulk discounts and one complimentary faculty membership included. Benefits include certification/eLearning discounts, a digital PMBOK Guide and Agile Practice Guide, and networking/volunteering access through the local PMI chapter. More info is available at PMI.org/GSM.

**Category:** Outreach / Academic  
**Source:** [Academic Outreach](https://www.pmichennai.org/academic-outreach/)  
**Confidence:** High  
**Tags:** GSM, group student membership, institution membership

**Related questions:**
- What is PMICC's Outreach Portfolio?
- Who leads PMICC's Outreach portfolio?
- How can my company partner with PMI Chennai Chapter?

---

### Q6. What is the PMI Global Accreditation Center (GAC)?

The GAC is PMI's specialized accrediting body for project management degree programs at the bachelor's, postgraduate, and doctorate levels. Over 170 higher-education project management programs worldwide have achieved GAC accreditation.

**Category:** Outreach / Academic  
**Source:** [Academic Outreach](https://www.pmichennai.org/academic-outreach/)  
**Confidence:** High  
**Tags:** GAC, accreditation, PM degree programs

**Related questions:**
- What is PMICC's Outreach Portfolio?
- Who leads PMICC's Outreach portfolio?
- How can my company partner with PMI Chennai Chapter?

---

### Q7. Which colleges has PMI Chennai Chapter partnered with?

Per the Academic Outreach page's event highlights, PMICC has active partnerships/MoUs with VIT Business School, Kumaraguru College of Technology (KCT) Coimbatore, Jansons Institutions, Sri Ramakrishna Engineering College (Coimbatore), and RICS-Crescent CoEBE, among others.

**Category:** Outreach / Academic  
**Source:** [Academic Outreach](https://www.pmichennai.org/academic-outreach/)  
**Confidence:** High  
**Tags:** college partnerships, MoU, VIT, KCT, Jansons, RICS Crescent

**Related questions:**
- What is PMICC's Outreach Portfolio?
- Who leads PMICC's Outreach portfolio?
- How can my company partner with PMI Chennai Chapter?

---

### Q8. What is a PMI Chapter Student Club and how do I join one?

A PMI Chapter Student Club is a student-led organization supported by PMICC that provides hands-on PM experience, leadership development, networking, career opportunities, and access to jobs/internships. PMICC has launched student clubs at institutions including Amrita School of Business, KCT Business School, and Jansons School of Business — check with your institution or PMICC's outreach team about starting or joining one.

**Category:** Outreach / Student Club  
**Source:** [Chapter Students Club](https://www.pmichennai.org/chapter-students-club/)  
**Confidence:** High  
**Tags:** student club, how to join, campus club

**Related questions:**
- What is PMICC's Outreach Portfolio?
- Who leads PMICC's Outreach portfolio?
- How can my company partner with PMI Chennai Chapter?

---

### Q9. What is the PMI Chennai Chapter Ambassador Program?

The Chapter Ambassador Program (CAP) is a flagship Corporate Outreach initiative connecting PMICC with local organizations across Chennai and Tamil Nadu. Ambassadors act as their organization's voice within PMICC, earn PDUs for participating in Ambassador meetings, and help grow PM awareness and PMI membership within their companies.

**Category:** Outreach / Chapter Ambassador  
**Source:** [Chapter Ambassador Program](https://www.pmichennai.org/chapter-ambassador-program/)  
**Confidence:** High  
**Tags:** chapter ambassador, CAP, corporate liaison

**Related questions:**
- What is PMICC's Outreach Portfolio?
- Who leads PMICC's Outreach portfolio?
- How can my company partner with PMI Chennai Chapter?

---

### Q10. Who is eligible to become a PMI Chennai Chapter Ambassador, and how do I apply?

You must be a member of both PMI and the PMI Chennai Chapter. Interested applicants complete the online Chapter Ambassador Application (a Google Form linked from the Chapter Ambassador Program page) or contact vpoutreach@pmi-chennai.org with questions.

**Category:** Outreach / Chapter Ambassador  
**Source:** [Chapter Ambassador Program](https://www.pmichennai.org/chapter-ambassador-program/)  
**Confidence:** High  
**Tags:** ambassador eligibility, how to apply, application form

**Related questions:**
- What is PMICC's Outreach Portfolio?
- Who leads PMICC's Outreach portfolio?
- How can my company partner with PMI Chennai Chapter?

---


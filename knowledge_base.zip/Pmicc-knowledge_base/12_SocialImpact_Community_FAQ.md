# 12 SocialImpact Community FAQ

### Q1. What social impact initiatives does PMI Chennai Chapter run?

Key initiatives include Project Puthri (life-skills sessions delivered to 10,000+ girls across 100+ Tamil Nadu schools since 2018), Project Nibuni (PM sessions in colleges in partnership with Avtar Trust, from January 2026), environmental drives (including planting 1,500 trees), and Thittamidu Vetrithodu, a Tamil-language project management book distributed to government schools. These align with UN Sustainable Development Goals.

**Category:** Social Impact / Overview  
**Source:** [Social Impact](https://www.pmichennai.org/socialimpact/)  
**Confidence:** High  
**Tags:** social impact, Project Puthri, Project Nibuni, Thittamidu Vetrithodu, UN SDGs

**Related questions:**
- How many members does PMI Chennai Chapter have now?

---

### Q2. How many members does PMI Chennai Chapter have now?

Per the Social Impact page, PMICC now has 3,200+ members (this is a more recent figure than the 1,500+ mentioned on the Volunteering Overview page, reflecting chapter growth over time).

**Category:** Social Impact / Member Count  
**Source:** [Social Impact](https://www.pmichennai.org/socialimpact/)  
**Confidence:** High  
**Tags:** member count, 3200 members, chapter growth

**Related questions:**
- What social impact initiatives does PMI Chennai Chapter run?

---

### Q3. Does PMI Chennai Chapter have a program for women members?

Yes — PMICHENNAI-WEC (Women Empowerment Committee), a dedicated group with 150+ women members across industries. It runs four initiatives: W-Greet n Meet (informal networking), W-Entrepreneur Connect (for women entrepreneurs), W-Pause and Restart (career-break support and return-to-work opportunities), and W-Groom (mentoring for female students). Contact vpwomenempowerment@pmi-chennai.org for more information.

**Category:** Community / Women Empowerment  
**Source:** [Women Empowerment](https://www.pmichennai.org/women-empowerment/)  
**Confidence:** High  
**Tags:** women empowerment, WEC, W-Pause and Restart, women members


---


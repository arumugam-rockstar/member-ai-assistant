# All Pages — Crawl Status

## Crawled & Extracted (source of truth for this knowledge base)

### Home
- **URL:** https://www.pmichennai.org/
- **Navigation Path:** Home
- **Category:** General / About
- **Last Updated (per site metadata):** 2026-07-06
- **Summary:** Homepage of the PMI Chennai Chapter (PMICC). Introduces the chapter as a non-profit, chartered component of the Project Management Institute (PMI), headquartered in Newtown Square, Pennsylvania, USA. Registered as a society under the Tamil Nadu Registration of Societies Act (not-for-profit, tax-exempt membership society). Covers chapter inception, vision, mission, upcoming events, recent news, full Board of Directors / chapter executives, additional chapter executives, photo gallery, academic and corporate partners, and contact details.
- **Contacts found:** President: Vijay Narayanan - president@pmi-chennai.org, +91 99404 38413 | Registered office: 715-A, 7th Floor, Spencer Plaza, Suite No.1182, Anna Salai, Chennai - 600 002, Mobile: +91 87785 66932
- **Keywords:** PMI Chennai, PMICC, about chapter, board of directors, chapter executives, vision, mission, history, inception, gallery, partners

### PMI Chennai Chapter Membership
- **URL:** https://www.pmichennai.org/pmicc-membership/
- **Navigation Path:** Home > About Us > PMI Chennai Chapter Membership
- **Category:** Membership
- **Last Updated (per site metadata):** 2026-05-20
- **Summary:** Describes PMICC's member-onboarding '3B Journey' (Belong-Believe-Become, a 30-60-90 day plan) and links members to PMI's global membership signup for the Chennai Chapter.
- **Contacts found:** General site contact per footer: 715-A, 7th Floor, Spencer Plaza, Suite No.1182, Mount Road, Anna Salai, Chennai - 600 002
- **Keywords:** membership, join PMI Chennai, 3B plan, onboarding, belong believe become, mentorship, Project Thunai

### Certification & Training
- **URL:** https://www.pmichennai.org/certification-training/
- **Navigation Path:** Home > Certification & Training
- **Category:** Certification & Training
- **Last Updated (per site metadata):** 2024-03-12
- **Summary:** Lists PMICC's training and certification preparation offerings (PMI-ACP, PgMP orientation, Microsoft Project, JIRA, ProjectLibre, Primavera). Contains archived workshop listings with historical fee structures, schedules, and registration contacts (content dated 2021-2022, retained on the page as of the last crawl).
- **Contacts found:** Certification/training registration: vpcertification@pmi-chennai.org / Training@pmi-chennai.org
- **Keywords:** PMP, PMI-ACP, PgMP, certification training, workshop, JIRA, Primavera, Microsoft Project, ProjectLibre, PDUs, fees

### Join Us - Volunteering Overview
- **URL:** https://www.pmichennai.org/join-us-volunteering-overview/
- **Navigation Path:** Home > Volunteering > Overview
- **Category:** Volunteering
- **Last Updated (per site metadata):** 2024-03-07
- **Summary:** Explains why to volunteer/join PMICC: notes PMICC has 1500+ members, describes chapter leadership development opportunities, and lists the general benefits of PMI membership (best practices, professional values, member-only services and discounts, publications, continuing education).
- **Contacts found:** General site contact per footer
- **Keywords:** volunteering, volunteer benefits, leadership development, 1500 members, PMI membership benefits

### PMP Certification Training
- **URL:** https://www.pmichennai.org/pmp/
- **Navigation Path:** Home > Certification & Training > PMP Certification Training
- **Category:** Certification & Training
- **Last Updated (per site metadata):** 2026-05-27
- **Summary:** Details PMICC's PMP (Project Management Professional) certification training: 100 total hours (35 hrs training + 35 hrs weekly preparation + 30 hrs 1-1 mock exam mentoring) with 180 days of support and mentoring. Open to anyone eligible per PMI's official PMP requirements.
- **Contacts found:** 715-A, 7th Floor, Spencer Plaza, Suite 1182, Anna Salai, Chennai 600002
- **Keywords:** PMP, PMP training, 100 hours, 180 days mentoring, PMP eligibility

### PMI ACP Certification Training
- **URL:** https://www.pmichennai.org/acp/
- **Navigation Path:** Home > Certification & Training > PMI ACP Certification Training
- **Category:** Certification & Training
- **Last Updated (per site metadata):** 2024-07-30
- **Summary:** PMI-ACP (Agile Certified Practitioner) training details, including an archived program schedule (17-24 Aug 2024, online) and fees: Rs. 10,620 for PMI Chapter Members and Rs. 11,800 for Non-Members (both inclusive of 18% GST).
- **Contacts found:** 715-A, 7th Floor, Spencer Plaza, Suite 1182, Anna Salai, Chennai 600002
- **Keywords:** PMI-ACP, agile certification, fees, member price, non-member price

### PgMP Certification Training
- **URL:** https://www.pmichennai.org/pgmp-certification-training/
- **Navigation Path:** Home > Certification & Training > PgMP Certification Training
- **Category:** Certification & Training
- **Last Updated (per site metadata):** 2025-12-01
- **Summary:** PMICC partners with INFOCAREER (a PMI Authorized Training Partner) to deliver PgMP training, including a 180-day 1:1 mentoring program (PgMP-Assure), learning tools (IC Prep Tracker+, e-learning portal, mock exams), and 24x7 support on working days.
- **Contacts found:** 715-A, 7th Floor, Spencer Plaza, Suite 1182, Anna Salai, Chennai 600002
- **Keywords:** PgMP, program management certification, INFOCAREER, mentoring, PgMP-Assure

### Outreach – An Overview
- **URL:** https://www.pmichennai.org/outreach/
- **Navigation Path:** Home > Outreach > Overview
- **Category:** Outreach
- **Last Updated (per site metadata):** 2025-08-12
- **Summary:** Describes PMICC's Outreach Portfolio connecting industry, academia, and community, aiming to help close the global talent gap (demand for 25 million project managers by 2030). Lists the Outreach leadership team.
- **Contacts found:** Outreach VP: Dr. B. Shyam Sundar - vpoutreach@pmi-chennai.org, +91 94455 42436 | AVP Outreach Advocacy: Srivikraman M - avpadvocacy@pmi-chennai.com, 8667302828
- **Keywords:** outreach, 25 million project managers by 2030, industry academia community

### Corporate Outreach
- **URL:** https://www.pmichennai.org/corporate-outreach/
- **Navigation Path:** Home > Outreach > Corporate Outreach
- **Category:** Outreach
- **Last Updated (per site metadata):** 2025-08-26
- **Summary:** Describes PMICC's corporate partnership strategy: customized training (PMP, PMI-ACP, CAPM), networking forums, joint academia-industry events, and volunteer opportunities for corporate professionals, aligned with corporate CSR goals.
- **Contacts found:** 715-A, 7th Floor, Spencer Plaza, Suite 1182, Anna Salai, Chennai 600002
- **Keywords:** corporate outreach, CSR, corporate training, CAPM, partnerships

### Academic Outreach
- **URL:** https://www.pmichennai.org/academic-outreach/
- **Navigation Path:** Home > Outreach > Academic Outreach
- **Category:** Outreach
- **Last Updated (per site metadata):** 2026-02-17
- **Summary:** Details PMICC's academic outreach connecting universities/colleges with PMI resources: PMI scholarships (US$1,000-US$7,500, applications open March), Group Student Membership (GSM, billed to institution with bulk discounts and one free faculty membership), PMI Authorized Training Partner (ATP) program, GAC accreditation, and CAPM/PMI-CP certifications for students. Lists recent academic partnership events (VIT Business School, Kumaraguru College of Technology, Jansons Institutions, Sri Ramakrishna Engineering College, RICS-Crescent CoEBE).
- **Contacts found:** 715-A, 7th Floor, Spencer Plaza, Suite 1182, Anna Salai, Chennai 600002
- **Keywords:** academic outreach, scholarships, GSM, ATP, GAC accreditation, CAPM, PMI-CP, MoU

### Chapter Students Club
- **URL:** https://www.pmichennai.org/chapter-students-club/
- **Navigation Path:** Home > Outreach > Chapter Students Club
- **Category:** Outreach
- **Last Updated (per site metadata):** 2025-12-19
- **Summary:** Explains PMI Chapter Student Clubs — student-led organizations supported by PMICC offering hands-on PM experience, leadership development, networking, and access to jobs/internships. Lists recent student club launches (Amrita School of Business, KCT Business School, Jansons School of Business).
- **Contacts found:** 715-A, 7th Floor, Spencer Plaza, Suite 1182, Anna Salai, Chennai 600002
- **Keywords:** student club, PMI student club, Amrita, KCT, Jansons, campus chapter

### Chapter Ambassador Program
- **URL:** https://www.pmichennai.org/chapter-ambassador-program/
- **Navigation Path:** Home > Outreach > Chapter Ambassador Program
- **Category:** Outreach
- **Last Updated (per site metadata):** 2025-08-12
- **Summary:** Describes the Chapter Ambassador Program (CAP), a flagship Corporate Outreach initiative connecting PMICC with local organizations across Chennai and Tamil Nadu. Ambassadors must be PMI and PMICC members, represent their organization, earn PDUs for participating, and apply via an online Google Form application.
- **Contacts found:** vpoutreach@pmi-chennai.org
- **Keywords:** chapter ambassador program, CAP, corporate liaison, PDUs, application

### Volunteering Opportunities (Enroll as Volunteer)
- **URL:** https://www.pmichennai.org/volunteeringopportunities/
- **Navigation Path:** Home > Volunteering > Enroll as Volunteer
- **Category:** Volunteering
- **Last Updated (per site metadata):** 2026-07-07
- **Summary:** Enrollment page for PMICC volunteering. Directs existing PMI members interested in volunteering to watch this section for new opportunities and reach out to the VP of Volunteer Development. Includes a QR code for volunteering signup.
- **Contacts found:** VP Volunteer Development: vpvolunteers@pmi-chennai.org
- **Keywords:** enroll as volunteer, volunteering opportunities, QR code, VP volunteer development

### Chapter Events
- **URL:** https://www.pmichennai.org/chapter-events/
- **Navigation Path:** Home > More > Chapter Events
- **Category:** Events
- **Last Updated (per site metadata):** 2026-07-11
- **Summary:** Lists PMICC's upcoming and past events. Upcoming (as of crawl): 'PMI Chennai Chapter First Workshop at Kovai - Fundamentals of AI' (1 Aug 2026, Coimbatore) and 'A Handshake Between Design Thinking & AI' (25 Jul 2026, IIT Madras Research Park). Past events include the Coimbatore Branch launch, Tech Talk on Agentic AI, Coffee & Connections networking, PM Tools Training, Kovai Sangamam 2026, and various GCOP/mentorship sessions.
- **Contacts found:** 715-A, 7th Floor, Spencer Plaza, Suite 1182, Anna Salai, Chennai 600002
- **Keywords:** chapter events, upcoming events, past events, Kovai Sangamam, workshops

### PMI Chennai Chapter Comes Home to Coimbatore
- **URL:** https://www.pmichennai.org/pmicc-coimbatore-branch/
- **Navigation Path:** Home > News > PMI Chennai Chapter Comes Home to Coimbatore
- **Category:** News / Regional Presence
- **Last Updated (per site metadata):** 2026-07-07
- **Summary:** Announces the inauguration of the PMI Chennai Chapter - Coimbatore Branch at Kovai Sangamam 2026, with Thiru C.K. Kumaravel (CMD, Naturals) as Chief Guest and Mr. Rajendran Dandapani (Director, Zoho Corporation) inaugurating. Event drew 300+ delegates and 10+ speakers.
- **Contacts found:** 715-A, 7th Floor, Spencer Plaza, Suite 1182, Anna Salai, Chennai 600002
- **Keywords:** Coimbatore branch, Kovai Sangamam 2026, branch launch, Zoho, inauguration

### Social Impact
- **URL:** https://www.pmichennai.org/socialimpact/
- **Navigation Path:** Home > More > Social Impact
- **Category:** Social Impact
- **Last Updated (per site metadata):** 2026-03-27
- **Summary:** Details PMICC's Social Impact Portfolio aligned to UN SDGs. States PMICC won the PMI Chapter of the Year Award 2025 (announced at PMI Global Summit 2025, Phoenix, Arizona). States chapter now has 3,200+ members. Major initiatives: Project Puthri (10,000+ girls across 100+ TN schools since 2018), Project Nibuni (PM sessions in colleges with Avtar Trust from Jan 2026), environmental drives (1,500 trees planted), and the Thittamidu Vetrithodu Tamil-language PM book distributed to government schools.
- **Contacts found:** 715-A, 7th Floor, Spencer Plaza, Suite 1182, Anna Salai, Chennai 600002
- **Keywords:** social impact, SDG, Chapter of the Year 2025, Project Puthri, Project Nibuni, 3200 members, Thittamidu Vetrithodu

### Women Empowerment
- **URL:** https://www.pmichennai.org/women-empowerment/
- **Navigation Path:** Home > More > Women Empowerment
- **Category:** Community / Diversity
- **Last Updated (per site metadata):** 2025-03-17
- **Summary:** Describes PMICHENNAI-WEC (Women Empowerment Committee), a dedicated group for women members with 150+ women from diverse industries. Four initiative pillars: W-Greet n Meet, W-Entrepreneur Connect, W-Pause and Restart, and W-Groom (mentoring for female students). Launched at the chapter's 20th Anniversary Curtain Raiser (28 May 2022).
- **Contacts found:** vpwomenempowerment@pmi-chennai.org
- **Keywords:** women empowerment, WEC, W-Greet n Meet, W-Pause and Restart, W-Groom, 150 women members

### Career++
- **URL:** https://www.pmichennai.org/career/
- **Navigation Path:** Home > More > Career++
- **Category:** Career Resources
- **Last Updated (per site metadata):** 2026-05-01
- **Summary:** A career FAQ and resume-guidance page for project management professionals, covering transitions to program/product management, PMP certification benefits, AI's impact on PM careers, resume structure guidelines, and a downloadable sample resume template. Links to the PMI global job board (pmjobs.pmi.org).
- **Contacts found:** 715-A, 7th Floor, Spencer Plaza, Suite 1182, Anna Salai, Chennai 600002
- **Keywords:** career FAQ, resume guidelines, PMI job board, career transition, AI impact on PM

## Identified via navigation menu but NOT yet crawled/extracted

- [ ] **Awards and Accolades (dedicated page)** — https://www.pmichennai.org/awards-own-by-pmi-chennai/  
  _robots.txt disallows automated fetch — key facts (Chapter of the Year 2025) recovered via search snippet and Social Impact page instead_
- [ ] **Oracle Primavera Workshop** — https://www.pmichennai.org/oracle-primavera-workshop/  
  _not fetched this pass_
- [ ] **Design Thinking for Project Managers** — https://www.pmichennai.org/design-thinking/  
  _not fetched this pass_
- [ ] **Leading with Purpose (Lead Up)** — https://www.pmichennai.org/lead-up/  
  _not fetched this pass_
- [ ] **Essentials of PM Using MS Project** — https://www.pmichennai.org/essentials-of-project-management-using-microsoft-project/  
  _not fetched this pass_
- [ ] **Volunteer Recognitions** — https://www.pmichennai.org/volunteer-recognitions/  
  _not fetched this pass_
- [ ] **Volunteer Voice** — https://www.pmichennai.org/volunteer-voice/  
  _not fetched this pass_
- [ ] **Chapter Highlights / News (index)** — https://www.pmichennai.org/chapter-news/  
  _not fetched this pass_
- [ ] **Events Calendar** — https://www.pmichennai.org/events-calendar/  
  _likely overlaps with Chapter Events, already crawled_
- [ ] **Events Gallery** — https://www.pmichennai.org/events-gallery/  
  _image-only content, low text-extraction value_
- [ ] **Newsletter** — https://www.pmichennai.org/newsletter/  
  _not fetched this pass_
- [ ] **PMI AI Assistant** — https://www.pmichennai.org/pmi-ai-assitant/  
  _not fetched this pass_

**Crawled this pass (18 pages total):** Home, PMICC Membership, Certification & Training (index), Volunteering Overview, PMP, PMI-ACP, PgMP, Outreach Overview, Corporate Outreach, Academic Outreach, Chapter Students Club, Chapter Ambassador Program, Enroll as Volunteer, Chapter Events, Coimbatore Branch launch, Social Impact, Women Empowerment, Career++.

*To extend further, fetch the remaining URLs above and re-run the extraction pipeline; the data.json structure supports incremental additions.*

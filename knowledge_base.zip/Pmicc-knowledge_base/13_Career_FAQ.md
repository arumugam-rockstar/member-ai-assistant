# 13 Career FAQ

### Q1. Does PMI Chennai Chapter provide career guidance or job resources?

Yes — the Career++ page offers a project management career FAQ (covering topics like transitioning to program management, AI's impact on PM careers, and career changes), resume writing guidelines with a downloadable template, and a link to PMI's global job board (pmjobs.pmi.org).

**Category:** Career / Resources  
**Source:** [Career++](https://www.pmichennai.org/career/)  
**Confidence:** High  
**Tags:** career resources, resume template, job board, career FAQ

**Related questions:**
- What resume format does PMI Chennai Chapter recommend?

---

### Q2. What resume format does PMI Chennai Chapter recommend?

The Career++ page recommends: keep resumes to two pages, be concise and specific (avoid generic terms like 'team player'), avoid personal details (marital status, religion, date of birth, salary), and structure it with Basic Details, Summary, Experience (most recent first), Academics, Certifications, and Professional Memberships sections. A downloadable sample resume template is provided on the page.

**Category:** Career / Resume  
**Source:** [Career++](https://www.pmichennai.org/career/)  
**Confidence:** High  
**Tags:** resume guidelines, resume format, resume template

**Related questions:**
- Does PMI Chennai Chapter provide career guidance or job resources?

---


# 11 Events FAQ

### Q1. What events does PMI Chennai Chapter have coming up?

As of the last crawl (site content dated July 2026), upcoming events listed include 'PMI Chennai Chapter First Workshop at Kovai - Fundamentals of Artificial Intelligence' (Saturday, 1 August 2026, in Coimbatore) and a paid workshop 'A Handshake Between Design Thinking & AI' (25 July 2026, at Nagarjuna Hall, IIT Madras Research Park). Check the Chapter Events and Events Calendar pages directly for the latest listings, since this changes frequently.

**Category:** Events / Upcoming Events  
**Source:** [Chapter Events](https://www.pmichennai.org/chapter-events/)  
**Confidence:** Medium  
**Tags:** upcoming events, event calendar, AI workshop, design thinking workshop

**Related questions:**
- What is Kovai Sangamam?

---

### Q2. What is Kovai Sangamam?

Kovai Sangamam is PMICC's flagship conference/summit held in Coimbatore ('Kovai'). Kovai Sangamam 2026 was notably the occasion at which the PMI Chennai Chapter - Coimbatore Branch was formally inaugurated, with 300+ delegates and 10+ speakers in attendance.

**Category:** Events / Flagship Event  
**Source:** [PMI Chennai Chapter Comes Home to Coimbatore](https://www.pmichennai.org/pmicc-coimbatore-branch/)  
**Confidence:** High  
**Tags:** Kovai Sangamam, flagship conference, Coimbatore event

**Related questions:**
- What events does PMI Chennai Chapter have coming up?

---

### Q3. When and how was the PMI Chennai Chapter Coimbatore Branch launched?

The PMI Chennai Chapter - Coimbatore Branch was inaugurated at Kovai Sangamam 2026, with Thiru C. K. Kumaravel (CMD, Naturals) as Chief Guest and Mr. Rajendran Dandapani (Director, Zoho Corporation) inaugurating the branch. Chapter President Vijay Narayanan, Secretary Vijay Mohan Gandhi, and several VPs attended, along with 300+ delegates and 10+ speakers.

**Category:** Regional Presence / Coimbatore Branch  
**Source:** [PMI Chennai Chapter Comes Home to Coimbatore](https://www.pmichennai.org/pmicc-coimbatore-branch/)  
**Confidence:** High  
**Tags:** Coimbatore branch launch, Kovai Sangamam 2026, branch inauguration


---

